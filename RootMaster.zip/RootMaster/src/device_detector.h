/**
 * device_detector.h
 * Handles device detection, information gathering, and compatibility checking.
 */

#ifndef DEVICE_DETECTOR_H
#define DEVICE_DETECTOR_H

#include <string>
#include <vector>
#include <map>
#include "utils/adb_interface.h"

// Represents basic device information
struct DeviceInfo {
    std::string id;        // Device serial number or identifier
    std::string model;     // Device model
    std::string state;     // Device connection state (e.g., "device", "recovery", "bootloader")
};

// Represents detailed device information
struct DetailedDeviceInfo {
    std::string id;
    std::string model;
    std::string manufacturer;
    std::string androidVersion;
    std::string cpuArch;
    std::string buildFingerprint;
    bool bootloaderUnlocked;
    bool isSupported;
    std::string unsupportedReason;
};

class DeviceDetector {
public:
    DeviceDetector();
    ~DeviceDetector();
    
    // Returns a list of connected Android devices
    std::vector<DeviceInfo> detectDevices();
    
    // Checks if a specific device is connected
    bool isDeviceConnected(const std::string& deviceId);
    
    // Gets detailed information about a specific device
    DetailedDeviceInfo getDetailedInfo(const std::string& deviceId);
    
    // Check device compatibility for rooting
    bool isDeviceCompatible(const DetailedDeviceInfo& deviceInfo);
    
    // Check if device is in fastboot mode
    bool isInFastbootMode(const std::string& deviceId);
    
    // Check if device is in recovery mode
    bool isInRecoveryMode(const std::string& deviceId);
    
private:
    Utils::AdbInterface adb;
    
    // Parse ADB output to get device list
    std::vector<DeviceInfo> parseAdbDevices(const std::string& output);
    
    // Parse fastboot output to get device list
    std::vector<DeviceInfo> parseFastbootDevices(const std::string& output);
    
    // Get device properties using ADB
    std::map<std::string, std::string> getDeviceProperties(const std::string& deviceId);
    
    // Check if the device is blacklisted (known to be problematic)
    bool isDeviceBlacklisted(const DetailedDeviceInfo& deviceInfo);
};

#endif // DEVICE_DETECTOR_H

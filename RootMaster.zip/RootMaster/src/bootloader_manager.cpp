/**
 * bootloader_manager.cpp
 * Implementation of bootloader unlocking operations.
 */

#include "bootloader_manager.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <algorithm>
#include <limits>

BootloaderManager::BootloaderManager() {
    // Initialize resources
}

BootloaderManager::~BootloaderManager() {
    // Clean up resources
}

bool BootloaderManager::unlockBootloader(const std::string& deviceId, std::shared_ptr<DeviceProfile> deviceProfile) {
    if (!deviceProfile) {
        std::cerr << "Error: No device profile provided for bootloader unlocking." << std::endl;
        return false;
    }
    
    // Check if bootloader is already unlocked
    if (isBootloaderUnlocked(deviceId)) {
        std::cout << "Bootloader is already unlocked." << std::endl;
        return true;
    }
    
    std::cout << "Preparing to unlock bootloader..." << std::endl;
    
    // Enable OEM unlock in developer options if needed
    if (deviceProfile->requiresOemUnlockEnabled()) {
        std::cout << "Checking OEM unlock status..." << std::endl;
        if (!deviceProfile->enableOemUnlock(deviceId)) {
            std::cerr << "Failed to enable OEM unlock in developer options." << std::endl;
            std::cerr << "Please enable it manually: Settings -> Developer options -> OEM unlocking" << std::endl;
            return false;
        }
    }
    
    // Reboot to bootloader
    std::cout << "Rebooting to bootloader mode..." << std::endl;
    if (!rebootToBootloader(deviceId)) {
        std::cerr << "Failed to reboot to bootloader mode." << std::endl;
        return false;
    }
    
    // Wait for device to appear in fastboot
    if (!waitForFastbootDevice(deviceId)) {
        std::cerr << "Device did not appear in fastboot mode." << std::endl;
        return false;
    }
    
    // Execute manufacturer-specific unlock sequence
    std::cout << "Executing bootloader unlock sequence..." << std::endl;
    if (!executeUnlockSequence(deviceId, deviceProfile)) {
        std::cerr << "Failed to execute bootloader unlock sequence." << std::endl;
        return false;
    }
    
    std::cout << "Bootloader unlock command sent." << std::endl;
    std::cout << "You may need to confirm the unlock on your device screen." << std::endl;
    
    // Wait for user to confirm on device if necessary
    std::cout << "Press Enter after confirming the unlock on your device (if prompted)..." << std::endl;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    
    // Check if unlock was successful
    if (!isBootloaderUnlocked(deviceId)) {
        std::cerr << "Bootloader appears to still be locked. Unlock may have failed." << std::endl;
        return false;
    }
    
    // Reboot the device
    std::cout << "Rebooting device..." << std::endl;
    if (!rebootDevice(deviceId)) {
        std::cerr << "Failed to reboot device after unlocking." << std::endl;
        // Not treating this as a fatal error, as unlock may have succeeded
    }
    
    return true;
}

bool BootloaderManager::rebootToBootloader(const std::string& deviceId) {
    // Check if device is already in fastboot mode
    if (fastboot.isDeviceConnected(deviceId)) {
        std::cout << "Device is already in fastboot mode." << std::endl;
        return true;
    }
    
    // Try to reboot to bootloader
    std::string command = "-s " + deviceId + " reboot bootloader";
    std::string output = adb.executeCommand(command);
    
    // Wait a moment for the reboot to start
    std::this_thread::sleep_for(std::chrono::seconds(3));
    
    // Check if device appears in fastboot
    return waitForFastbootDevice(deviceId);
}

bool BootloaderManager::rebootDevice(const std::string& deviceId) {
    // Check if device is in fastboot mode
    if (fastboot.isDeviceConnected(deviceId)) {
        std::string command = "reboot";
        std::string output = fastboot.executeCommand(command, deviceId);
        return output.find("failed") == std::string::npos;
    }
    
    // If device is in ADB mode
    std::string command = "-s " + deviceId + " reboot";
    std::string output = adb.executeCommand(command);
    return output.find("error") == std::string::npos;
}

bool BootloaderManager::isBootloaderUnlocked(const std::string& deviceId) {
    // First, check if device is in fastboot mode
    if (fastboot.isDeviceConnected(deviceId)) {
        std::string output = fastboot.executeCommand("getvar unlocked", deviceId);
        return output.find("unlocked: yes") != std::string::npos;
    }
    
    // If in ADB mode, try to check through getprop
    std::string command = "-s " + deviceId + " shell getprop ro.boot.flash.locked";
    std::string output = adb.executeCommand(command);
    
    // Trim whitespace
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output == "0") {
        return true;
    }
    
    // Try alternative property for some devices
    command = "-s " + deviceId + " shell getprop ro.boot.unlocked";
    output = adb.executeCommand(command);
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output == "true" || output == "1") {
        return true;
    }
    
    // One more check for some devices
    command = "-s " + deviceId + " shell getprop ro.bootloader.unlocked";
    output = adb.executeCommand(command);
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    return (output == "1");
}

bool BootloaderManager::waitForFastbootDevice(const std::string& deviceId, int timeoutSeconds) {
    std::cout << "Waiting for device to appear in fastboot mode..." << std::endl;
    
    for (int i = 0; i < timeoutSeconds; i++) {
        if (fastboot.isDeviceConnected(deviceId)) {
            std::cout << "Device detected in fastboot mode." << std::endl;
            return true;
        }
        
        // Check for any fastboot device if specific ID isn't found
        if (fastboot.isAnyDeviceConnected()) {
            std::cout << "A device is in fastboot mode, but its ID may have changed." << std::endl;
            return true;
        }
        
        std::cout << "." << std::flush;
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    
    std::cout << std::endl << "Timeout waiting for device in fastboot mode." << std::endl;
    return false;
}

bool BootloaderManager::executeUnlockSequence(const std::string& deviceId, std::shared_ptr<DeviceProfile> deviceProfile) {
    // Get the appropriate unlock command from the device profile
    std::string unlockCommand = deviceProfile->getBootloaderUnlockCommand();
    
    if (unlockCommand.empty()) {
        std::cerr << "No unlock command available for this device model." << std::endl;
        return false;
    }
    
    // Execute the unlock command
    std::string output = fastboot.executeCommand(unlockCommand, deviceId);
    
    // Check for common error messages
    if (output.find("FAILED") != std::string::npos) {
        std::cerr << "Unlock command failed: " << output << std::endl;
        return false;
    }
    
    return true;
}

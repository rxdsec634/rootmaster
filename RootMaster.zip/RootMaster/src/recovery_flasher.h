/**
 * recovery_flasher.h
 * Handles flashing custom recovery images.
 */

#ifndef RECOVERY_FLASHER_H
#define RECOVERY_FLASHER_H

#include <string>
#include <memory>
#include "device_profiles/device_profile.h"
#include "utils/adb_interface.h"
#include "utils/fastboot_interface.h"

class RecoveryFlasher {
public:
    RecoveryFlasher();
    ~RecoveryFlasher();
    
    // Flash a custom recovery image to the device
    bool flashRecovery(const std::string& deviceId, std::shared_ptr<DeviceProfile> deviceProfile, 
                       const std::string& recoveryImagePath);
    
    // Reboot device into recovery mode
    bool rebootToRecovery(const std::string& deviceId);
    
private:
    Utils::AdbInterface adb;
    Utils::FastbootInterface fastboot;
    
    // Verify the recovery image exists and is valid
    bool verifyRecoveryImage(const std::string& recoveryImagePath);
    
    // Reboot to bootloader if needed
    bool ensureDeviceInBootloader(const std::string& deviceId);
    
    // Wait for device to appear in fastboot mode
    bool waitForFastbootDevice(const std::string& deviceId, int timeoutSeconds = 60);
    
    // Wait for device to appear in recovery mode
    bool waitForRecoveryDevice(const std::string& deviceId, int timeoutSeconds = 60);
};

#endif // RECOVERY_FLASHER_H

/**
 * superuser_installer.h
 * Handles installation of superuser binaries (e.g., Magisk).
 */

#ifndef SUPERUSER_INSTALLER_H
#define SUPERUSER_INSTALLER_H

#include <string>
#include <memory>
#include "device_profiles/device_profile.h"
#include "utils/adb_interface.h"

class SuperuserInstaller {
public:
    SuperuserInstaller();
    ~SuperuserInstaller();
    
    // Install superuser binaries (Magisk)
    bool installSuperuser(const std::string& deviceId, 
                           std::shared_ptr<DeviceProfile> deviceProfile,
                           const std::string& magiskPath);
    
    // Verify Magisk installation success
    bool verifyMagiskInstallation(const std::string& deviceId);
    
private:
    Utils::AdbInterface adb;
    
    // Verify Magisk ZIP file
    bool verifyMagiskZip(const std::string& magiskPath);
    
    // Ensure device is in recovery mode
    bool ensureDeviceInRecovery(const std::string& deviceId);
    
    // Push Magisk ZIP to device
    bool pushMagiskToDevice(const std::string& deviceId, const std::string& magiskPath);
    
    // Install Magisk ZIP in recovery mode
    bool installMagiskInRecovery(const std::string& deviceId, const std::string& magiskPath);
    
    // Wait for device to boot normally
    bool waitForNormalBoot(const std::string& deviceId, int timeoutSeconds = 120);
};

#endif // SUPERUSER_INSTALLER_H

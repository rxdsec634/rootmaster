/**
 * RXDSEC: Android Device Rooting Tool
 * A cross-platform C/C++ command-line tool for rooting Android devices
 * through bootloader unlocking, custom recovery flashing, and superuser binary installation.
 * Developed by RXDSEC Security Research Team.
 */

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <cstdlib>
#include <thread>
#include <chrono>
#include <filesystem>
#include <regex>

#include "device_detector.h"
#include "bootloader_manager.h"
#include "recovery_flasher.h"
#include "superuser_installer.h"
#include "device_profiles/device_profile.h"
#include "device_profiles/pixel.h"
#include "device_profiles/samsung.h"
#include "device_profiles/xiaomi.h"
#include "device_profiles/bbk.h"
#include "device_profiles/transsion.h"
#include "utils/platform.h"
#include "utils/filesystem.h"
#include "utils/downloader.h"

void displayLegalWarning() {
    std::cout << "=========================================================================" << std::endl;
    std::cout << "                            *** WARNING ***                             " << std::endl;
    std::cout << "=========================================================================" << std::endl;
    std::cout << "This tool modifies your Android device in ways that may void your warranty." << std::endl;
    std::cout << "Rooting your device comes with the following risks:" << std::endl;
    std::cout << "  - Warranty voiding" << std::endl;
    std::cout << "  - Security vulnerabilities" << std::endl;
    std::cout << "  - Device bricking (making your device unusable)" << std::endl;
    std::cout << "  - Data loss" << std::endl;
    std::cout << std::endl;
    std::cout << "Some device manufacturers may detect rooting and refuse service." << std::endl;
    std::cout << "Using this tool may violate terms of service for some applications." << std::endl;
    std::cout << std::endl;
    std::cout << "The authors of this tool are NOT responsible for any damage caused." << std::endl;
    std::cout << "Proceed at your own risk." << std::endl;
    std::cout << "=========================================================================" << std::endl;
    
    std::cout << "Do you understand and accept these risks? (yes/no): ";
    std::string response;
    std::getline(std::cin, response);
    
    if (response != "yes") {
        std::cout << "Operation canceled by user." << std::endl;
        exit(0);
    }
}

void displayHelp() {
    std::cout << "=======================================================" << std::endl;
    std::cout << "      ____   __   __ ____   _____ _____ _____ " << std::endl;
    std::cout << "     |  _ \\ \\ \\ / /|  _ \\ / ____|  ___/ ____|" << std::endl;
    std::cout << "     | |_) | \\ V / | | | | (___  | |__| |     " << std::endl;
    std::cout << "     |  _ <   > <  | |  | |\\___ \\ |  __| |     " << std::endl;
    std::cout << "     | | \\ \\ / . \\ | |__| |____) || |__| |____ " << std::endl;
    std::cout << "     |_|  \\_/_/ \\_\\|_____/|_____/ |_____|_____|" << std::endl;
    std::cout << "=======================================================" << std::endl;
    std::cout << "                  Developed by @rxdsec                  " << std::endl;
    std::cout << "=======================================================" << std::endl;
    std::cout << "RXDSEC: Android Device Rooting Tool" << std::endl;
    std::cout << "Usage: rootmaster [command] [options]" << std::endl;
    std::cout << std::endl;
    std::cout << "Commands:" << std::endl;
    std::cout << "  detect             - Detect connected Android devices" << std::endl;
    std::cout << "  info               - Display detailed information about connected devices" << std::endl;
    std::cout << "  download           - Download recovery images and Magisk installer" << std::endl;
    std::cout << "  unlock DEVICE_ID   - Unlock bootloader (if supported)" << std::endl;
    std::cout << "  flash DEVICE_ID    - Flash custom recovery" << std::endl;
    std::cout << "  root DEVICE_ID     - Install superuser binary (Magisk)" << std::endl;
    std::cout << "  auto DEVICE_ID     - Perform complete rooting process automatically" << std::endl;
    std::cout << "  help               - Display this help message" << std::endl;
    std::cout << std::endl;
    std::cout << "Options:" << std::endl;
    std::cout << "  --recovery PATH    - Specify path to custom recovery image" << std::endl;
    std::cout << "  --magisk PATH      - Specify path to Magisk installer APK/ZIP" << std::endl;
    std::cout << "  --force            - Bypass compatibility checks (dangerous)" << std::endl;
    std::cout << "  --no-warning       - Skip legal warning (not recommended)" << std::endl;
}

int main(int argc, char* argv[]) {
    // Set up program
    Utils::Platform::initialize();
    Utils::Filesystem::createTempDirectories();
    
    // Parse command line arguments
    std::vector<std::string> args;
    for (int i = 1; i < argc; i++) {
        args.push_back(argv[i]);
    }
    
    if (args.empty() || (args.size() == 1 && args[0] == "help")) {
        displayHelp();
        return 0;
    }
    
    // Check for no-warning flag
    bool showWarning = true;
    for (const auto& arg : args) {
        if (arg == "--no-warning") {
            showWarning = false;
            break;
        }
    }
    
    // Display legal warning unless bypassed
    if (showWarning) {
        displayLegalWarning();
    }
    
    // Initialize modules
    DeviceDetector detector;
    BootloaderManager bootloader;
    RecoveryFlasher recovery;
    SuperuserInstaller superuser;
    
    // Process commands
    std::string command = args[0];
    
    if (command == "detect") {
        std::cout << "Detecting Android devices..." << std::endl;
        auto devices = detector.detectDevices();
        if (devices.empty()) {
            std::cout << "No Android devices detected. Please check USB connection and ensure USB debugging is enabled." << std::endl;
            return 1;
        }
        
        std::cout << "Found " << devices.size() << " device(s):" << std::endl;
        for (const auto& device : devices) {
            std::cout << "  - " << device.id << ": " << device.model << " (" << device.state << ")" << std::endl;
        }
    }
    else if (command == "info") {
        std::cout << "Gathering detailed device information..." << std::endl;
        auto devices = detector.detectDevices();
        if (devices.empty()) {
            std::cout << "No Android devices detected." << std::endl;
            return 1;
        }
        
        for (const auto& device : devices) {
            std::cout << "Device: " << device.model << " (" << device.id << ")" << std::endl;
            auto info = detector.getDetailedInfo(device.id);
            std::cout << "  - Model: " << info.model << std::endl;
            std::cout << "  - Android Version: " << info.androidVersion << std::endl;
            std::cout << "  - Bootloader Status: " << (info.bootloaderUnlocked ? "Unlocked" : "Locked") << std::endl;
            std::cout << "  - CPU Architecture: " << info.cpuArch << std::endl;
            std::cout << "  - Manufacturer: " << info.manufacturer << std::endl;
            std::cout << "  - Build Fingerprint: " << info.buildFingerprint << std::endl;
            std::cout << "  - Supported by RXDSEC: " << (info.isSupported ? "Yes" : "No") << std::endl;
            if (!info.isSupported) {
                std::cout << "    Reason: " << info.unsupportedReason << std::endl;
            }
            std::cout << std::endl;
        }
    }
    else if (command == "download") {
        std::cout << "===== Recovery and Magisk Downloader =====" << std::endl;
        std::cout << "This tool will help you download the necessary files for rooting your device." << std::endl;
        
        // Initialize downloader
        Utils::Downloader downloader;
        
        // First, detect devices to get device information
        auto devices = detector.detectDevices();
        std::string deviceModel = "";
        std::string manufacturer = "";
        
        if (!devices.empty()) {
            std::cout << "\nDetected device(s):" << std::endl;
            int i = 1;
            for (const auto& device : devices) {
                auto info = detector.getDetailedInfo(device.id);
                std::cout << i << ". " << info.model << " (" << info.manufacturer << ")" << std::endl;
                i++;
            }
            
            std::cout << "\nSelect a device or enter 'manual' to specify manually: ";
            std::string selection;
            std::getline(std::cin, selection);
            
            if (selection != "manual") {
                try {
                    int selectedIndex = std::stoi(selection) - 1;
                    if (selectedIndex >= 0 && static_cast<size_t>(selectedIndex) < devices.size()) {
                        auto info = detector.getDetailedInfo(devices[selectedIndex].id);
                        deviceModel = info.model;
                        manufacturer = info.manufacturer;
                    }
                } catch (const std::exception& e) {
                    // Handle invalid input
                }
            }
        }
        
        if (deviceModel.empty()) {
            std::cout << "Available manufacturers:" << std::endl;
            std::cout << "1. Google/Pixel" << std::endl;
            std::cout << "2. Samsung" << std::endl;
            std::cout << "3. Xiaomi/Redmi" << std::endl;
            std::cout << "4. OnePlus/Oppo/Vivo/Realme (BBK)" << std::endl;
            std::cout << "5. Tecno/Infinix/Itel (Transsion)" << std::endl;
            std::cout << "6. Other" << std::endl;
            
            std::cout << "Select manufacturer: ";
            std::string mfgSelection;
            std::getline(std::cin, mfgSelection);
            
            // Convert selection to manufacturer name
            try {
                int mfgIndex = std::stoi(mfgSelection);
                switch(mfgIndex) {
                    case 1: manufacturer = "Google"; break;
                    case 2: manufacturer = "Samsung"; break;
                    case 3: manufacturer = "Xiaomi"; break;
                    case 4: manufacturer = "BBK"; break;
                    case 5: manufacturer = "Transsion"; break;
                    default: manufacturer = "Other";
                }
            } catch (const std::exception& e) {
                manufacturer = "Other";
            }
            
            std::cout << "Enter device model: ";
            std::getline(std::cin, deviceModel);
        }
        
        // Create download directories
        std::string downloadsDir = "downloads";
        std::filesystem::create_directories(downloadsDir);
        
        // Set paths for downloaded files
        std::string magiskPath = downloadsDir + "/magisk_latest.apk";  // Changed to .apk as default
        std::string recoveryPath = downloadsDir + "/recovery_" + 
                                   std::regex_replace(deviceModel, std::regex("[^a-zA-Z0-9]"), "_") + 
                                   ".img";
        
        // Download Magisk
        std::cout << "\n1. Downloading Magisk Installer..." << std::endl;
        bool magiskSuccess = downloader.downloadMagisk(magiskPath, "latest");
        if (magiskSuccess) {
            std::cout << "✓ Magisk downloaded successfully to: " << magiskPath << std::endl;
        } else {
            std::cout << "⨯ Failed to download Magisk. Please check your internet connection and try again." << std::endl;
            magiskPath = "";
        }
        
        // Download recovery image
        std::cout << "\n2. Downloading recovery image for " << deviceModel << " (" << manufacturer << ")..." << std::endl;
        bool recoverySuccess = downloader.downloadRecoveryImage(deviceModel, manufacturer, recoveryPath);
        if (recoverySuccess) {
            std::cout << "✓ Recovery image downloaded successfully to: " << recoveryPath << std::endl;
        } else {
            std::cout << "⨯ Failed to find a specific recovery image for your device model." << std::endl;
            std::cout << "You may need to manually download the appropriate recovery image." << std::endl;
            recoveryPath = "";
        }
        
        // Show instructions
        std::cout << "\n===== Next Steps =====" << std::endl;
        if (!magiskPath.empty() && !recoveryPath.empty()) {
            std::cout << "Files downloaded successfully! You can now proceed with rooting your device using:" << std::endl;
            std::cout << "rootmaster auto <DEVICE_ID> --recovery " << recoveryPath << " --magisk " << magiskPath << std::endl;
        } else if (!magiskPath.empty()) {
            std::cout << "Only Magisk was downloaded successfully. You'll need to manually download a recovery image." << std::endl;
            std::cout << "Once you have the recovery image, you can proceed with:" << std::endl;
            std::cout << "rootmaster auto <DEVICE_ID> --recovery <PATH_TO_RECOVERY> --magisk " << magiskPath << std::endl;
        } else {
            std::cout << "Downloads failed. Please check your internet connection and try again." << std::endl;
        }
    }
    else if (command == "unlock" && args.size() > 1) {
        std::string deviceId = args[1];
        std::cout << "Attempting to unlock bootloader for device: " << deviceId << std::endl;
        
        if (!detector.isDeviceConnected(deviceId)) {
            std::cout << "Error: Device not found. Please check connection and device ID." << std::endl;
            return 1;
        }
        
        auto deviceInfo = detector.getDetailedInfo(deviceId);
        std::shared_ptr<DeviceProfile> profile = DeviceProfile::createProfileForDevice(deviceInfo);
        
        if (!profile) {
            std::cout << "Error: Unsupported device model." << std::endl;
            return 1;
        }
        
        std::cout << "WARNING: Unlocking bootloader will erase all data on your device!" << std::endl;
        std::cout << "Make sure you have backed up any important data before proceeding." << std::endl;
        std::cout << "Do you want to continue? (yes/no): ";
        std::string response;
        std::getline(std::cin, response);
        
        if (response != "yes") {
            std::cout << "Bootloader unlock aborted." << std::endl;
            return 0;
        }
        
        bool success = bootloader.unlockBootloader(deviceId, profile);
        if (success) {
            std::cout << "Bootloader unlocked successfully!" << std::endl;
        } else {
            std::cout << "Failed to unlock bootloader. Check logs for details." << std::endl;
            return 1;
        }
    }
    else if (command == "flash" && args.size() > 1) {
        std::string deviceId = args[1];
        std::string recoveryPath = "";
        
        // Check for recovery path argument
        for (size_t i = 0; i < args.size() - 1; i++) {
            if (args[i] == "--recovery") {
                recoveryPath = args[i + 1];
                break;
            }
        }
        
        if (recoveryPath.empty()) {
            std::cout << "Error: Recovery image path not specified. Use --recovery PATH." << std::endl;
            return 1;
        }
        
        if (!detector.isDeviceConnected(deviceId)) {
            std::cout << "Error: Device not found. Please check connection and device ID." << std::endl;
            return 1;
        }
        
        auto deviceInfo = detector.getDetailedInfo(deviceId);
        if (!deviceInfo.bootloaderUnlocked) {
            std::cout << "Error: Bootloader must be unlocked before flashing recovery." << std::endl;
            std::cout << "Run 'rootmaster unlock " << deviceId << "' first." << std::endl;
            return 1;
        }
        
        std::shared_ptr<DeviceProfile> profile = DeviceProfile::createProfileForDevice(deviceInfo);
        if (!profile) {
            std::cout << "Error: Unsupported device model." << std::endl;
            return 1;
        }
        
        bool success = recovery.flashRecovery(deviceId, profile, recoveryPath);
        if (success) {
            std::cout << "Custom recovery flashed successfully!" << std::endl;
        } else {
            std::cout << "Failed to flash recovery. Check logs for details." << std::endl;
            return 1;
        }
    }
    else if (command == "root" && args.size() > 1) {
        std::string deviceId = args[1];
        std::string magiskPath = "";
        
        // Check for Magisk path argument
        for (size_t i = 0; i < args.size() - 1; i++) {
            if (args[i] == "--magisk") {
                magiskPath = args[i + 1];
                break;
            }
        }
        
        if (magiskPath.empty()) {
            std::cout << "Error: Magisk installer path not specified. Use --magisk PATH." << std::endl;
            return 1;
        }
        
        if (!detector.isDeviceConnected(deviceId)) {
            std::cout << "Error: Device not found. Please check connection and device ID." << std::endl;
            return 1;
        }
        
        auto deviceInfo = detector.getDetailedInfo(deviceId);
        std::shared_ptr<DeviceProfile> profile = DeviceProfile::createProfileForDevice(deviceInfo);
        
        if (!profile) {
            std::cout << "Error: Unsupported device model." << std::endl;
            return 1;
        }
        
        bool success = superuser.installSuperuser(deviceId, profile, magiskPath);
        if (success) {
            std::cout << "Superuser (Magisk) installed successfully!" << std::endl;
            std::cout << "Your device is now rooted." << std::endl;
        } else {
            std::cout << "Failed to install Magisk. Check logs for details." << std::endl;
            return 1;
        }
    }
    else if (command == "auto" && args.size() > 1) {
        std::string deviceId = args[1];
        std::string recoveryPath = "";
        std::string magiskPath = "";
        bool force = false;
        
        // Parse options
        for (size_t i = 0; i < args.size() - 1; i++) {
            if (args[i] == "--recovery") {
                recoveryPath = args[i + 1];
            }
            else if (args[i] == "--magisk") {
                magiskPath = args[i + 1];
            }
            else if (args[i] == "--force") {
                force = true;
            }
        }
        
        if (recoveryPath.empty()) {
            std::cout << "Error: Recovery image path not specified. Use --recovery PATH." << std::endl;
            return 1;
        }
        
        if (magiskPath.empty()) {
            std::cout << "Error: Magisk installer path not specified. Use --magisk PATH." << std::endl;
            return 1;
        }
        
        if (!detector.isDeviceConnected(deviceId)) {
            std::cout << "Error: Device not found. Please check connection and device ID." << std::endl;
            return 1;
        }
        
        auto deviceInfo = detector.getDetailedInfo(deviceId);
        std::shared_ptr<DeviceProfile> profile = DeviceProfile::createProfileForDevice(deviceInfo);
        
        if (!profile && !force) {
            std::cout << "Error: Unsupported device model. Use --force to attempt anyway (dangerous)." << std::endl;
            return 1;
        }
        
        std::cout << "Starting automatic rooting process for " << deviceInfo.model << std::endl;
        std::cout << "This process will:" << std::endl;
        std::cout << "1. Unlock the bootloader (will erase all data)" << std::endl;
        std::cout << "2. Flash custom recovery" << std::endl;
        std::cout << "3. Install Magisk" << std::endl;
        std::cout << std::endl;
        std::cout << "WARNING: This is a potentially dangerous operation that could brick your device." << std::endl;
        std::cout << "Make sure you have backed up all important data." << std::endl;
        std::cout << "Do you want to proceed? (yes/no): ";
        
        std::string response;
        std::getline(std::cin, response);
        
        if (response != "yes") {
            std::cout << "Automatic rooting aborted." << std::endl;
            return 0;
        }
        
        // 1. Unlock bootloader
        if (!deviceInfo.bootloaderUnlocked) {
            std::cout << "\nStep 1/3: Unlocking bootloader..." << std::endl;
            bool unlockSuccess = bootloader.unlockBootloader(deviceId, profile);
            if (!unlockSuccess) {
                std::cout << "Failed to unlock bootloader. Aborting." << std::endl;
                return 1;
            }
            
            // Wait for device to reboot after bootloader unlock
            std::cout << "Waiting for device to reboot..." << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(10));
            
            int retries = 30;
            while (retries > 0 && !detector.isDeviceConnected(deviceId)) {
                std::cout << "Waiting for device to reconnect... " << retries << std::endl;
                std::this_thread::sleep_for(std::chrono::seconds(2));
                retries--;
            }
            
            if (!detector.isDeviceConnected(deviceId)) {
                std::cout << "Device did not reconnect after bootloader unlock. Please reconnect manually and retry." << std::endl;
                return 1;
            }
        } else {
            std::cout << "\nStep 1/3: Bootloader already unlocked. Skipping." << std::endl;
        }
        
        // 2. Flash custom recovery
        std::cout << "\nStep 2/3: Flashing custom recovery..." << std::endl;
        bool flashSuccess = recovery.flashRecovery(deviceId, profile, recoveryPath);
        if (!flashSuccess) {
            std::cout << "Failed to flash recovery. Aborting." << std::endl;
            return 1;
        }
        
        // 3. Install Magisk
        std::cout << "\nStep 3/3: Installing Magisk..." << std::endl;
        bool magiskSuccess = superuser.installSuperuser(deviceId, profile, magiskPath);
        if (!magiskSuccess) {
            std::cout << "Failed to install Magisk." << std::endl;
            return 1;
        }
        
        std::cout << "\nAutomatic rooting completed successfully!" << std::endl;
        std::cout << "Your device is now rooted with Magisk." << std::endl;
    }
    else {
        std::cout << "Unknown command or missing arguments." << std::endl;
        displayHelp();
        return 1;
    }
    
    // Clean up resources
    Utils::Filesystem::cleanupTempDirectories();
    return 0;
}

/**
 * pixel.cpp
 * Implementation of Google Pixel device-specific profile.
 */

#include "pixel.h"
#include <iostream>
#include <algorithm>
#include <regex>
#include <filesystem>

PixelProfile::PixelProfile() {
    // Initialize list of supported Pixel models
    supportedModels = {
        "pixel", "pixel xl", 
        "pixel 2", "pixel 2 xl", 
        "pixel 3", "pixel 3 xl", "pixel 3a", "pixel 3a xl",
        "pixel 4", "pixel 4 xl", "pixel 4a", "pixel 4a 5g",
        "pixel 5", "pixel 5a",
        "pixel 6", "pixel 6 pro", "pixel 6a",
        "pixel 7", "pixel 7 pro", "pixel 7a",
        "nexus 5x", "nexus 6p"
    };
}

bool PixelProfile::requiresOemUnlockEnabled() const {
    return true;
}

bool PixelProfile::enableOemUnlock(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Check if developer options are already enabled
    std::string output = adb.executeCommand("-s " + deviceId + " shell settings get global development_settings_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Enabling Developer Options..." << std::endl;
        
        // Enable developer options
        adb.executeCommand("-s " + deviceId + " shell settings put global development_settings_enabled 1");
        
        // Set user to current user ID
        adb.executeCommand("-s " + deviceId + " shell settings put global development_settings_enabled_for_users 1");
    }
    
    // Check if OEM unlock is already enabled
    output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Attempting to enable OEM Unlock..." << std::endl;
        
        // Try to enable OEM unlock
        adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
        
        // Verify it was enabled
        output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
        output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
        
        if (output != "1") {
            std::cout << "WARNING: Failed to enable OEM Unlock automatically." << std::endl;
            std::cout << "Please enable it manually in Settings -> Developer options -> OEM unlocking" << std::endl;
            return false;
        }
    }
    
    return true;
}

std::string PixelProfile::getBootloaderUnlockCommand() const {
    return "flashing unlock";
}

std::string PixelProfile::getRecoveryFlashCommand(const std::string& recoveryImagePath) const {
    std::string partitionName = getRecoveryPartitionName();
    return "flash " + partitionName + " \"" + recoveryImagePath + "\"";
}

std::string PixelProfile::getRecoveryPartitionName() const {
    return "recovery";
}

std::map<std::string, std::string> PixelProfile::getSpecialCommands() const {
    std::map<std::string, std::string> commands;
    
    // No special commands needed for Pixel devices
    
    return commands;
}

std::string PixelProfile::getManufacturer() const {
    return "Google";
}

bool PixelProfile::supportsModel(const std::string& model) const {
    // Convert model to lowercase for case-insensitive comparison
    std::string modelLower = model;
    std::transform(modelLower.begin(), modelLower.end(), modelLower.begin(), ::tolower);
    
    // Check against our list of supported models
    for (const auto& supportedModel : supportedModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    // Also check for generic identifiers
    if (modelLower.find("pixel") != std::string::npos ||
        modelLower.find("nexus") != std::string::npos) {
        return true;
    }
    
    return false;
}

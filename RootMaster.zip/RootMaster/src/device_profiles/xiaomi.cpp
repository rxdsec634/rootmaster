/**
 * xiaomi.cpp
 * Implementation of Xiaomi/Redmi device-specific profile.
 */

#include "xiaomi.h"
#include <iostream>
#include <algorithm>
#include <regex>
#include <filesystem>

XiaomiProfile::XiaomiProfile() {
    // Initialize list of supported Xiaomi/Redmi models (both model names and identifiers)
    supportedModels = {
        // Xiaomi
        "mi", "xiaomi", "poco",
        "mi 8", "mi 9", "mi 10", "mi 11", "mi 12",
        "mi note", "mi max", "mi mix", "mi a1", "mi a2", "mi a3",
        "pocophone", "poco f1", "poco f2", "poco f3", "poco f4", "poco f5",
        "poco x3", "poco x4", "poco x5", 
        "poco m3", "poco m4", "poco m5",
        // Redmi
        "redmi", "redmi note",
        "redmi note 8", "redmi note 9", "redmi note 10", "redmi note 11", "redmi note 12",
        "redmi 9", "redmi 10", "redmi 11", "redmi 12", "redmi k20", "redmi k30", "redmi k40", "redmi k50"
    };
    
    // Models known to require EDL mode for unlocking (typically newer devices with anti-rollback)
    edlUnlockModels = {
        "mi 11", "mi 12", "redmi note 10", "redmi note 11", "redmi note 12", "poco f4", "poco f5"
    };
    
    // Models with anti-rollback protection
    antiRollbackModels = {
        "mi 8", "mi 9", "mi 10", "mi 11", "mi 12",
        "redmi note 8", "redmi note 9", "redmi note 10", "redmi note 11", "redmi note 12",
        "poco f3", "poco f4", "poco f5", "poco x3", "poco x4", "poco x5"
    };
}

bool XiaomiProfile::requiresOemUnlockEnabled() const {
    return true;
}

bool XiaomiProfile::enableOemUnlock(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Check if developer options are already enabled
    std::string output = adb.executeCommand("-s " + deviceId + " shell settings get global development_settings_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Enabling Developer Options..." << std::endl;
        
        // Enable developer options
        adb.executeCommand("-s " + deviceId + " shell settings put global development_settings_enabled 1");
    }
    
    // For Xiaomi, we need to enable OEM unlock and also USB debugging
    // Check if OEM unlock is already enabled
    output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Attempting to enable OEM Unlock..." << std::endl;
        
        // Try to enable OEM unlock
        adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
        
        // Verify it was enabled
        output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
        output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
        
        if (output != "1") {
            std::cout << "WARNING: Failed to enable OEM Unlock automatically." << std::endl;
            std::cout << "Please enable it manually in Settings -> Developer options -> OEM unlocking" << std::endl;
            return false;
        }
    }
    
    return true;
}

std::string XiaomiProfile::getBootloaderUnlockCommand() const {
    // Xiaomi uses a different unlock command
    return "oem unlock-go";
}

std::string XiaomiProfile::getRecoveryFlashCommand(const std::string& recoveryImagePath) const {
    std::string partitionName = getRecoveryPartitionName();
    return "flash " + partitionName + " \"" + recoveryImagePath + "\"";
}

std::string XiaomiProfile::getRecoveryPartitionName() const {
    return "recovery";
}

std::map<std::string, std::string> XiaomiProfile::getSpecialCommands() const {
    std::map<std::string, std::string> commands;
    
    // Xiaomi often requires disabling verification
    commands["disable_verification"] = "fastboot oem disable-verification";
    
    // Add reboot to fastboot mode
    commands["reboot_fastboot"] = "adb reboot bootloader";
    
    // Add command to check unlock status
    commands["check_unlock_status"] = "fastboot oem device-info";
    
    return commands;
}

std::string XiaomiProfile::getManufacturer() const {
    return "Xiaomi";
}

bool XiaomiProfile::supportsModel(const std::string& model) const {
    // Convert model to lowercase for case-insensitive comparison
    std::string modelLower = model;
    std::transform(modelLower.begin(), modelLower.end(), modelLower.begin(), ::tolower);
    
    // Check against our list of supported models
    for (const auto& supportedModel : supportedModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

bool XiaomiProfile::isMiUnlockToolRequired() const {
    // Xiaomi devices typically require Mi Unlock Tool and an unlock code
    return true;
}

bool XiaomiProfile::hasAntiRollbackProtection(const std::string& deviceId) const {
    // Extract model from deviceId or device information
    // This is a simplified implementation; in practice, we'd extract the actual model
    
    // For simplicity, we'll just check against our known list
    std::string modelLower = deviceId;
    std::transform(modelLower.begin(), modelLower.end(), modelLower.begin(), ::tolower);
    
    for (const auto& arModel : antiRollbackModels) {
        if (modelLower.find(arModel) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

bool XiaomiProfile::requiresEDLUnlock() const {
    // Some newer Xiaomi devices require EDL mode for unlocking
    // This would be determined based on the specific model
    return false; // Default is false, would be overridden for specific models
}
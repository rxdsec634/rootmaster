/**
 * xiaomi.h
 * Xiaomi/Redmi device-specific profile.
 */

#ifndef XIAOMI_PROFILE_H
#define XIAOMI_PROFILE_H

#include "device_profile.h"

class XiaomiProfile : public DeviceProfile {
public:
    XiaomiProfile();
    ~XiaomiProfile() override = default;
    
    // Check if device requires OEM unlock to be enabled in developer options
    bool requiresOemUnlockEnabled() const override;
    
    // Enable OEM unlock in developer options
    bool enableOemUnlock(const std::string& deviceId) const override;
    
    // Get the fastboot command to unlock the bootloader
    std::string getBootloaderUnlockCommand() const override;
    
    // Get the fastboot command to flash recovery image
    std::string getRecoveryFlashCommand(const std::string& recoveryImagePath) const override;
    
    // Get the recovery partition name
    std::string getRecoveryPartitionName() const override;
    
    // Get any special ADB commands needed for this device
    std::map<std::string, std::string> getSpecialCommands() const override;
    
    // Get the manufacturer name
    std::string getManufacturer() const override;
    
    // Checks if the profile supports a specific device model
    bool supportsModel(const std::string& model) const override;
    
    // Additional Xiaomi-specific methods
    bool isMiUnlockToolRequired() const;
    
    // Check if device uses anti-rollback protection
    bool hasAntiRollbackProtection(const std::string& deviceId) const;
    
    // Check if device requires unlocking through EDL mode
    bool requiresEDLUnlock() const;

private:
    // List of supported Xiaomi/Redmi models
    std::vector<std::string> supportedModels;
    
    // List of models requiring EDL mode unlocking
    std::vector<std::string> edlUnlockModels;
    
    // List of models with anti-rollback protection
    std::vector<std::string> antiRollbackModels;
};

#endif // XIAOMI_PROFILE_H
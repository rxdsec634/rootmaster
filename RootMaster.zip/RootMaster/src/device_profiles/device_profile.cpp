/**
 * device_profile.cpp
 * Implementation of device profile base class and factory method.
 */

#include "device_profile.h"
#include "pixel.h"
#include "samsung.h"
#include "xiaomi.h"
#include "bbk.h"
#include "transsion.h"
#include "../device_detector.h" // Include for DetailedDeviceInfo struct
#include <algorithm>
#include <memory>
#include <iostream>

std::shared_ptr<DeviceProfile> DeviceProfile::createProfileForDevice(const DetailedDeviceInfo& deviceInfo) {
    // Convert manufacturer to lowercase for case-insensitive comparison
    std::string manufacturer = deviceInfo.manufacturer;
    std::transform(manufacturer.begin(), manufacturer.end(), manufacturer.begin(), ::tolower);
    
    // Convert model to lowercase for case-insensitive comparison
    std::string model = deviceInfo.model;
    std::transform(model.begin(), model.end(), model.begin(), ::tolower);
    
    std::cout << "Detecting profile for device: " << deviceInfo.manufacturer << " " << deviceInfo.model << std::endl;
    
    // Create profile based on manufacturer
    if (manufacturer.find("google") != std::string::npos ||
        manufacturer.find("pixel") != std::string::npos) {
        // Google Pixel devices
        auto profile = std::make_shared<PixelProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using Google Pixel device profile" << std::endl;
            return profile;
        }
    }
    else if (manufacturer.find("samsung") != std::string::npos) {
        // Samsung devices
        auto profile = std::make_shared<SamsungProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using Samsung device profile" << std::endl;
            return profile;
        }
    }
    else if (manufacturer.find("xiaomi") != std::string::npos ||
             manufacturer.find("redmi") != std::string::npos ||
             manufacturer.find("poco") != std::string::npos) {
        // Xiaomi/Redmi/Poco devices
        auto profile = std::make_shared<XiaomiProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using Xiaomi device profile" << std::endl;
            return profile;
        }
    }
    else if (manufacturer.find("oppo") != std::string::npos ||
             manufacturer.find("vivo") != std::string::npos ||
             manufacturer.find("realme") != std::string::npos ||
             manufacturer.find("oneplus") != std::string::npos ||
             manufacturer.find("iqoo") != std::string::npos) {
        // BBK Electronics brands
        auto profile = std::make_shared<BBKProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using BBK Electronics device profile" << std::endl;
            return profile;
        }
    }
    else if (manufacturer.find("tecno") != std::string::npos ||
             manufacturer.find("infinix") != std::string::npos ||
             manufacturer.find("itel") != std::string::npos ||
             manufacturer.find("transsion") != std::string::npos) {
        // Transsion Holdings brands
        auto profile = std::make_shared<TranssionProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using Transsion device profile" << std::endl;
            return profile;
        }
    }
    
    // As a fallback, try to identify based on model name
    std::cout << "Manufacturer not recognized, trying to identify based on model name..." << std::endl;
    
    // Try Xiaomi/Redmi profile
    if (model.find("mi") != std::string::npos ||
        model.find("redmi") != std::string::npos ||
        model.find("poco") != std::string::npos) {
        auto profile = std::make_shared<XiaomiProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using Xiaomi device profile (based on model)" << std::endl;
            return profile;
        }
    }
    
    // Try BBK brands profile
    if (model.find("oppo") != std::string::npos ||
        model.find("vivo") != std::string::npos ||
        model.find("realme") != std::string::npos ||
        model.find("oneplus") != std::string::npos ||
        model.find("reno") != std::string::npos ||
        model.find("find") != std::string::npos ||
        model.find("nord") != std::string::npos) {
        auto profile = std::make_shared<BBKProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using BBK Electronics device profile (based on model)" << std::endl;
            return profile;
        }
    }
    
    // Try Transsion profile
    if (model.find("tecno") != std::string::npos ||
        model.find("infinix") != std::string::npos ||
        model.find("itel") != std::string::npos ||
        model.find("camon") != std::string::npos ||
        model.find("spark") != std::string::npos ||
        model.find("hot") != std::string::npos) {
        auto profile = std::make_shared<TranssionProfile>();
        if (profile->supportsModel(deviceInfo.model)) {
            std::cout << "Using Transsion device profile (based on model)" << std::endl;
            return profile;
        }
    }
    
    // Try Pixel profile
    auto pixelProfile = std::make_shared<PixelProfile>();
    if (pixelProfile->supportsModel(deviceInfo.model)) {
        std::cout << "Using Google Pixel device profile (based on model)" << std::endl;
        return pixelProfile;
    }
    
    // Try Samsung profile
    auto samsungProfile = std::make_shared<SamsungProfile>();
    if (samsungProfile->supportsModel(deviceInfo.model)) {
        std::cout << "Using Samsung device profile (based on model)" << std::endl;
        return samsungProfile;
    }
    
    // No matching profile found
    std::cout << "WARNING: No specific device profile found for: " << deviceInfo.manufacturer << " " << deviceInfo.model << std::endl;
    return nullptr;
}

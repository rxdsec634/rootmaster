/**
 * transsion.h
 * Transsion Holdings device-specific profile (Tecno, Infinix, Itel).
 */

#ifndef TRANSSION_PROFILE_H
#define TRANSSION_PROFILE_H

#include "device_profile.h"

class TranssionProfile : public DeviceProfile {
public:
    TranssionProfile();
    ~TranssionProfile() override = default;
    
    // Check if device requires OEM unlock to be enabled in developer options
    bool requiresOemUnlockEnabled() const override;
    
    // Enable OEM unlock in developer options
    bool enableOemUnlock(const std::string& deviceId) const override;
    
    // Get the fastboot command to unlock the bootloader
    std::string getBootloaderUnlockCommand() const override;
    
    // Get the fastboot command to flash recovery image
    std::string getRecoveryFlashCommand(const std::string& recoveryImagePath) const override;
    
    // Get the recovery partition name
    std::string getRecoveryPartitionName() const override;
    
    // Get any special ADB commands needed for this device
    std::map<std::string, std::string> getSpecialCommands() const override;
    
    // Get the manufacturer name
    std::string getManufacturer() const override;
    
    // Checks if the profile supports a specific device model
    bool supportsModel(const std::string& model) const override;
    
    // Transsion-specific methods
    enum class TranssionBrand {
        TECNO,
        INFINIX,
        ITEL,
        UNKNOWN
    };
    
    TranssionBrand detectBrand(const std::string& deviceId) const;
    bool isPCTestPointRequired() const;
    bool requiresAuthenticationFile() const;

private:
    // List of supported models for various Transsion brands
    std::vector<std::string> supportedTecnoModels;
    std::vector<std::string> supportedInfinixModels;
    std::vector<std::string> supportedItelModels;
    
    // Models that require PCB test point method
    std::vector<std::string> testPointModels;
};

#endif // TRANSSION_PROFILE_H
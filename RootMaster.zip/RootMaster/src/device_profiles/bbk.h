/**
 * bbk.h
 * BBK Electronics device-specific profile (Oppo, Vivo, Realme, OnePlus).
 */

#ifndef BBK_PROFILE_H
#define BBK_PROFILE_H

#include "device_profile.h"

class BBKProfile : public DeviceProfile {
public:
    BBKProfile();
    ~BBKProfile() override = default;
    
    // Check if device requires OEM unlock to be enabled in developer options
    bool requiresOemUnlockEnabled() const override;
    
    // Enable OEM unlock in developer options
    bool enableOemUnlock(const std::string& deviceId) const override;
    
    // Get the fastboot command to unlock the bootloader
    std::string getBootloaderUnlockCommand() const override;
    
    // Get the fastboot command to flash recovery image
    std::string getRecoveryFlashCommand(const std::string& recoveryImagePath) const override;
    
    // Get the recovery partition name
    std::string getRecoveryPartitionName() const override;
    
    // Get any special ADB commands needed for this device
    std::map<std::string, std::string> getSpecialCommands() const override;
    
    // Get the manufacturer name
    std::string getManufacturer() const override;
    
    // Checks if the profile supports a specific device model
    bool supportsModel(const std::string& model) const override;
    
    // BBK-specific methods
    bool requiresDeepTestingMode() const;
    bool isMtkDevice(const std::string& deviceId) const;
    bool isColorOSDevice(const std::string& deviceId) const;
    
    // For some BBK devices, we need to detect the actual brand
    enum class BBKBrand {
        OPPO,
        VIVO,
        REALME,
        ONEPLUS,
        UNKNOWN
    };
    
    BBKBrand detectBrand(const std::string& deviceId) const;
    
private:
    // List of supported models for various BBK brands
    std::vector<std::string> supportedOppoModels;
    std::vector<std::string> supportedVivoModels;
    std::vector<std::string> supportedRealmeModels;
    std::vector<std::string> supportedOnePlusModels;
    
    // List of MediaTek-based devices that need specific handling
    std::vector<std::string> mtkDevices;
};

#endif // BBK_PROFILE_H
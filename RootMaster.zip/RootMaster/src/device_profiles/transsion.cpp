/**
 * transsion.cpp
 * Implementation of Transsion Holdings device profiles (Tecno, Infinix, Itel).
 */

#include "transsion.h"
#include <iostream>
#include <algorithm>
#include <regex>

TranssionProfile::TranssionProfile() {
    // Initialize supported Tecno models
    supportedTecnoModels = {
        "tecno", "camon", "spark", "pova", "phantom",
        "camon 15", "camon 16", "camon 17", "camon 18", "camon 19", "camon 20",
        "spark 5", "spark 6", "spark 7", "spark 8", "spark 9", "spark 10",
        "pova", "pova 2", "pova 3", "pova 4", "pova 5",
        "phantom", "phantom x"
    };
    
    // Initialize supported Infinix models
    supportedInfinixModels = {
        "infinix", "hot", "note", "zero", "smart",
        "hot 10", "hot 11", "hot 12", "hot 20", "hot 30",
        "note 8", "note 10", "note 11", "note 12", "note 30",
        "zero 8", "zero x", "zero 30",
        "smart 5", "smart 6", "smart 7"
    };
    
    // Initialize supported Itel models
    supportedItelModels = {
        "itel", "a", "p", "s",
        "a58", "a60", "a70",
        "p36", "p37", "p38",
        "s17", "s18"
    };
    
    // Models that require PCB test point method
    testPointModels = {
        "camon 19", "camon 20", "spark 9", "spark 10",
        "hot 30", "note 30", "zero 30"
    };
}

bool TranssionProfile::requiresOemUnlockEnabled() const {
    return true;
}

bool TranssionProfile::enableOemUnlock(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Check if developer options are already enabled
    std::string output = adb.executeCommand("-s " + deviceId + " shell settings get global development_settings_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Enabling Developer Options..." << std::endl;
        
        // Enable developer options
        adb.executeCommand("-s " + deviceId + " shell settings put global development_settings_enabled 1");
    }
    
    // Transsion devices use HiOS/XOS which have different paths to OEM unlock
    TranssionBrand brand = detectBrand(deviceId);
    
    std::cout << "For " << (brand == TranssionBrand::TECNO ? "TECNO" : 
                           (brand == TranssionBrand::INFINIX ? "Infinix" : 
                           (brand == TranssionBrand::ITEL ? "Itel" : "Transsion"))) 
              << " devices:" << std::endl;
              
    std::cout << "1. Go to Settings > About Phone" << std::endl;
    std::cout << "2. Tap 'Build Number' or 'Version' 7 times" << std::endl;
    std::cout << "3. Go to Developer Options and enable OEM Unlocking" << std::endl;
    
    // Try to enable OEM unlock programmatically
    adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
    
    // Verify OEM unlock is enabled
    output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "WARNING: Could not verify OEM Unlock status. Please enable it manually." << std::endl;
        return false;
    }
    
    return true;
}

std::string TranssionProfile::getBootloaderUnlockCommand() const {
    // Transsion devices typically use standard unlock command
    return "flashing unlock";
}

std::string TranssionProfile::getRecoveryFlashCommand(const std::string& recoveryImagePath) const {
    std::string partitionName = getRecoveryPartitionName();
    return "flash " + partitionName + " \"" + recoveryImagePath + "\"";
}

std::string TranssionProfile::getRecoveryPartitionName() const {
    return "recovery";
}

std::map<std::string, std::string> TranssionProfile::getSpecialCommands() const {
    std::map<std::string, std::string> commands;
    
    // Special commands for Transsion devices
    commands["format_data"] = "fastboot -w";
    commands["erase_frp"] = "fastboot erase frp";
    commands["enter_edl"] = "adb reboot edl";
    commands["disable_dm_verity"] = "fastboot oem disable_dm_verity";
    
    return commands;
}

std::string TranssionProfile::getManufacturer() const {
    return "Transsion Holdings";
}

bool TranssionProfile::supportsModel(const std::string& model) const {
    // Convert model to lowercase for case-insensitive comparison
    std::string modelLower = model;
    std::transform(modelLower.begin(), modelLower.end(), modelLower.begin(), ::tolower);
    
    // Check against various Transsion brand models
    for (const auto& supportedModel : supportedTecnoModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    for (const auto& supportedModel : supportedInfinixModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    for (const auto& supportedModel : supportedItelModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

TranssionProfile::TranssionBrand TranssionProfile::detectBrand(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Check model and manufacturer properties
    std::string manufacturer = adb.executeCommand("-s " + deviceId + " shell getprop ro.product.manufacturer");
    std::transform(manufacturer.begin(), manufacturer.end(), manufacturer.begin(), ::tolower);
    
    std::string model = adb.executeCommand("-s " + deviceId + " shell getprop ro.product.model");
    std::transform(model.begin(), model.end(), model.begin(), ::tolower);
    
    // Check brand property
    std::string brand = adb.executeCommand("-s " + deviceId + " shell getprop ro.product.brand");
    std::transform(brand.begin(), brand.end(), brand.begin(), ::tolower);
    
    // Check for TECNO
    if (brand.find("tecno") != std::string::npos || 
        manufacturer.find("tecno") != std::string::npos ||
        model.find("tecno") != std::string::npos ||
        model.find("camon") != std::string::npos || 
        model.find("spark") != std::string::npos ||
        model.find("pova") != std::string::npos ||
        model.find("phantom") != std::string::npos) {
        return TranssionBrand::TECNO;
    }
    
    // Check for Infinix
    if (brand.find("infinix") != std::string::npos || 
        manufacturer.find("infinix") != std::string::npos ||
        model.find("infinix") != std::string::npos ||
        model.find("hot") != std::string::npos ||
        model.find("note") != std::string::npos ||
        model.find("zero") != std::string::npos ||
        model.find("smart") != std::string::npos) {
        return TranssionBrand::INFINIX;
    }
    
    // Check for Itel
    if (brand.find("itel") != std::string::npos || 
        manufacturer.find("itel") != std::string::npos ||
        model.find("itel") != std::string::npos) {
        return TranssionBrand::ITEL;
    }
    
    // Unknown Transsion brand
    return TranssionBrand::UNKNOWN;
}

bool TranssionProfile::isPCTestPointRequired() const {
    // For some newer Transsion devices, unlocking requires a hardware test point
    // This could be determined by model using testPointModels list
    return false; // Default value, would be determined by specific model
}

bool TranssionProfile::requiresAuthenticationFile() const {
    // Some newer Transsion devices require an authentication file to unlock
    return false; // Default value, would be determined by specific model
}
/**
 * device_profile.h
 * Base class for device-specific profiles that provide tailored commands.
 */

#ifndef DEVICE_PROFILE_H
#define DEVICE_PROFILE_H

#include <string>
#include <memory>
#include <map>
#include "../utils/adb_interface.h"
#include "../device_detector.h" // Include for DetailedDeviceInfo struct

class DeviceProfile {
public:
    virtual ~DeviceProfile() = default;
    
    // Create the appropriate profile based on device information
    static std::shared_ptr<DeviceProfile> createProfileForDevice(const DetailedDeviceInfo& deviceInfo);
    
    // Check if device requires OEM unlock to be enabled in developer options
    virtual bool requiresOemUnlockEnabled() const = 0;
    
    // Enable OEM unlock in developer options
    virtual bool enableOemUnlock(const std::string& deviceId) const = 0;
    
    // Get the fastboot command to unlock the bootloader
    virtual std::string getBootloaderUnlockCommand() const = 0;
    
    // Get the fastboot command to flash recovery image
    virtual std::string getRecoveryFlashCommand(const std::string& recoveryImagePath) const = 0;
    
    // Get the recovery partition name
    virtual std::string getRecoveryPartitionName() const = 0;
    
    // Get any special ADB commands needed for this device
    virtual std::map<std::string, std::string> getSpecialCommands() const = 0;
    
    // Get the manufacturer name
    virtual std::string getManufacturer() const = 0;
    
    // Checks if the profile supports a specific device model
    virtual bool supportsModel(const std::string& model) const = 0;
};

#endif // DEVICE_PROFILE_H

/**
 * samsung.cpp
 * Implementation of Samsung device-specific profile.
 */

#include "samsung.h"
#include <iostream>
#include <algorithm>
#include <regex>
#include <filesystem>

SamsungProfile::SamsungProfile() {
    // Initialize list of supported Samsung models
    supportedModels = {
        "galaxy s7", "galaxy s7 edge",
        "galaxy s8", "galaxy s8+",
        "galaxy s9", "galaxy s9+",
        "galaxy s10", "galaxy s10+", "galaxy s10e",
        "galaxy s20", "galaxy s20+", "galaxy s20 ultra",
        "galaxy s21", "galaxy s21+", "galaxy s21 ultra",
        "galaxy note8", "galaxy note9", "galaxy note10", "galaxy note20",
        "galaxy a50", "galaxy a51", "galaxy a70", "galaxy a71"
    };
}

bool SamsungProfile::requiresOemUnlockEnabled() const {
    return true;
}

bool SamsungProfile::enableOemUnlock(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Check if Knox is enabled, which can complicate unlocking
    if (isKnoxEnabled(deviceId)) {
        std::cout << "WARNING: Samsung Knox detected on this device." << std::endl;
        std::cout << "Unlocking may trigger Knox security and void warranty." << std::endl;
    }
    
    // Check if developer options are already enabled
    std::string output = adb.executeCommand("-s " + deviceId + " shell settings get global development_settings_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Enabling Developer Options..." << std::endl;
        
        // Enable developer options
        adb.executeCommand("-s " + deviceId + " shell settings put global development_settings_enabled 1");
    }
    
    // Check if OEM unlock is already enabled
    output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Attempting to enable OEM Unlock..." << std::endl;
        
        // Try to enable OEM unlock
        adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
        
        // Verify it was enabled
        output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
        output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
        
        if (output != "1") {
            std::cout << "WARNING: Failed to enable OEM Unlock automatically." << std::endl;
            std::cout << "Please enable it manually in Settings -> Developer options -> OEM unlocking" << std::endl;
            return false;
        }
    }
    
    return true;
}

std::string SamsungProfile::getBootloaderUnlockCommand() const {
    // Samsung devices typically use "oem unlock" command
    // Some newer devices may use different commands or require special handling
    return "oem unlock";
}

std::string SamsungProfile::getRecoveryFlashCommand(const std::string& recoveryImagePath) const {
    std::string partitionName = getRecoveryPartitionName();
    
    // For Samsung, sometimes we need to use a different flash method
    // This is a simplification - real Samsung devices may need device-specific commands
    return "flash " + partitionName + " \"" + recoveryImagePath + "\"";
}

std::string SamsungProfile::getRecoveryPartitionName() const {
    // Samsung typically uses "recovery" partition, but some models vary
    return "recovery";
}

std::map<std::string, std::string> SamsungProfile::getSpecialCommands() const {
    std::map<std::string, std::string> commands;
    
    // Samsung special commands
    commands["enter_download"] = "reboot download"; // Enter download (Odin) mode
    
    return commands;
}

std::string SamsungProfile::getManufacturer() const {
    return "Samsung";
}

bool SamsungProfile::supportsModel(const std::string& model) const {
    // Convert model to lowercase for case-insensitive comparison
    std::string modelLower = model;
    std::transform(modelLower.begin(), modelLower.end(), modelLower.begin(), ::tolower);
    
    // Check against our list of supported models
    for (const auto& supportedModel : supportedModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    // Also check for generic Samsung identifiers
    if (modelLower.find("samsung") != std::string::npos ||
        modelLower.find("galaxy") != std::string::npos ||
        modelLower.find("sm-") != std::string::npos) {
        return true;
    }
    
    return false;
}

bool SamsungProfile::isKnoxEnabled(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Check for Knox properties
    std::string output = adb.executeCommand("-s " + deviceId + " shell getprop ro.knox.warranty_bit");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (!output.empty() && output != "0") {
        return true;
    }
    
    // Try alternative property
    output = adb.executeCommand("-s " + deviceId + " shell getprop ro.boot.warranty_bit");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    return (!output.empty() && output != "0");
}

bool SamsungProfile::isInOdinMode(const std::string& deviceId) const {
    // This is a simplification - detecting Odin mode requires vendor-specific tools
    // For a real implementation, we would need to use libusb to look for Samsung-specific 
    // USB identifiers in download mode
    
    return false;
}

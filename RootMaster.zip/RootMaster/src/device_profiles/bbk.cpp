/**
 * bbk.cpp
 * Implementation of BBK Electronics device profiles (Oppo, Vivo, Realme, OnePlus).
 */

#include "bbk.h"
#include <iostream>
#include <algorithm>
#include <regex>

BBKProfile::BBKProfile() {
    // Initialize supported Oppo models
    supportedOppoModels = {
        "oppo", "find", "reno", "a5", "a7", "a9", "a53", "a54", "a72", "a74",
        "f1", "f3", "f5", "f7", "f9", "f11", "f17", "f19",
        "r5", "r7", "r9", "r11", "r15", "r17"
    };
    
    // Initialize supported Vivo models
    supportedVivoModels = {
        "vivo", "x", "y", "v", "iqoo",
        "x50", "x60", "x70", "x80", "x90",
        "y11", "y12", "y15", "y20", "y21", "y33", "y35", "y51", "y53", "y55", "y73", "y75",
        "v9", "v11", "v15", "v17", "v19", "v20", "v21", "v23", "v25"
    };
    
    // Initialize supported Realme models
    supportedRealmeModels = {
        "realme", "gt", "narzo", 
        "realme 5", "realme 6", "realme 7", "realme 8", "realme 9", "realme 10", "realme 11",
        "realme c", "realme c1", "realme c2", "realme c3", "realme c11", "realme c12", "realme c15",
        "realme c20", "realme c21", "realme c25", "realme c30", "realme c31", "realme c33", "realme c35",
        "realme gt", "realme gt2", "realme gt neo"
    };
    
    // Initialize supported OnePlus models
    supportedOnePlusModels = {
        "oneplus", "one plus",
        "oneplus 5", "oneplus 5t", "oneplus 6", "oneplus 6t",
        "oneplus 7", "oneplus 7 pro", "oneplus 7t", "oneplus 7t pro",
        "oneplus 8", "oneplus 8 pro", "oneplus 8t",
        "oneplus 9", "oneplus 9 pro", "oneplus 9r", "oneplus 9rt",
        "oneplus 10", "oneplus 10 pro", "oneplus 10r", "oneplus 10t",
        "oneplus 11", "oneplus nord"
    };
    
    // MediaTek-based devices that need specific handling
    mtkDevices = {
        "realme 6", "realme 7", "realme 8", "realme c3", "realme c11", "realme c15",
        "oppo a53", "oppo a54", "oppo a72", "oppo a74", "reno 4",
        "vivo y11", "vivo y12", "vivo y15", "vivo y20", "vivo y21"
    };
}

bool BBKProfile::requiresOemUnlockEnabled() const {
    return true;
}

bool BBKProfile::enableOemUnlock(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Get the specific brand
    BBKBrand brand = detectBrand(deviceId);
    
    // Check if developer options are already enabled
    std::string output = adb.executeCommand("-s " + deviceId + " shell settings get global development_settings_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "Enabling Developer Options..." << std::endl;
        
        // Enable developer options
        adb.executeCommand("-s " + deviceId + " shell settings put global development_settings_enabled 1");
    }
    
    // BBK devices have different OEM unlock methods
    switch (brand) {
        case BBKBrand::OPPO:
        case BBKBrand::REALME:
            if (isColorOSDevice(deviceId)) {
                std::cout << "ColorOS device detected. For OEM unlock:" << std::endl;
                std::cout << "1. Go to Settings > About Phone" << std::endl;
                std::cout << "2. Tap 'Version' 7 times to enable Developer Options" << std::endl;
                std::cout << "3. Go to Settings > Developer Options > OEM Unlocking" << std::endl;
                
                // Attempt to enable via ADB anyway
                adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
            } else {
                // Standard method for non-ColorOS devices
                adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
            }
            break;
            
        case BBKBrand::VIVO:
            std::cout << "For Vivo devices, you need to:" << std::endl;
            std::cout << "1. Enable Developer Options by tapping Build Number 7 times" << std::endl;
            std::cout << "2. Go to Developer Options and enable 'OEM Unlocking'" << std::endl;
            std::cout << "3. Some Vivo devices may require a deep testing or fastboot mode" << std::endl;
            
            // Attempt to enable via ADB anyway
            adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
            break;
            
        case BBKBrand::ONEPLUS:
            // OnePlus devices use standard method
            adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
            break;
            
        default:
            // Generic method for unknown BBK devices
            adb.executeCommand("-s " + deviceId + " shell settings put secure oem_unlock_enabled 1");
            break;
    }
    
    // Verify OEM unlock is enabled
    output = adb.executeCommand("-s " + deviceId + " shell settings get secure oem_unlock_enabled");
    output.erase(std::remove_if(output.begin(), output.end(), ::isspace), output.end());
    
    if (output != "1") {
        std::cout << "WARNING: Could not verify OEM Unlock status. Please enable it manually." << std::endl;
        return false;
    }
    
    return true;
}

std::string BBKProfile::getBootloaderUnlockCommand() const {
    // BBK typically uses standard unlock command
    return "oem unlock";
}

std::string BBKProfile::getRecoveryFlashCommand(const std::string& recoveryImagePath) const {
    std::string partitionName = getRecoveryPartitionName();
    return "flash " + partitionName + " \"" + recoveryImagePath + "\"";
}

std::string BBKProfile::getRecoveryPartitionName() const {
    return "recovery";
}

std::map<std::string, std::string> BBKProfile::getSpecialCommands() const {
    std::map<std::string, std::string> commands;
    
    // Special commands for BBK devices
    commands["enter_deep_testing"] = "adb reboot bootloader && fastboot oem edl";
    commands["enable_device_unlock"] = "fastboot oem unlock-go";
    commands["bypass_auth"] = "fastboot flashing unlock_critical";
    
    // Different reboot commands
    commands["reboot_to_recovery"] = "adb reboot recovery";
    commands["reboot_to_bootloader"] = "adb reboot bootloader";
    commands["reboot_to_edl"] = "adb reboot edl";
    
    return commands;
}

std::string BBKProfile::getManufacturer() const {
    // Return generic manufacturer name
    return "BBK Electronics";
}

bool BBKProfile::supportsModel(const std::string& model) const {
    // Convert model to lowercase for case-insensitive comparison
    std::string modelLower = model;
    std::transform(modelLower.begin(), modelLower.end(), modelLower.begin(), ::tolower);
    
    // Check against various BBK brand models
    for (const auto& supportedModel : supportedOppoModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    for (const auto& supportedModel : supportedVivoModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    for (const auto& supportedModel : supportedRealmeModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    for (const auto& supportedModel : supportedOnePlusModels) {
        if (modelLower.find(supportedModel) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

bool BBKProfile::requiresDeepTestingMode() const {
    // Many OPPO, Realme, and Vivo devices require deep testing mode
    // This would be determined based on specific model
    return true;
}

bool BBKProfile::isMtkDevice(const std::string& deviceId) const {
    // Convert to lowercase for comparison
    std::string deviceIdLower = deviceId;
    std::transform(deviceIdLower.begin(), deviceIdLower.end(), deviceIdLower.begin(), ::tolower);
    
    // Check against known MediaTek models
    for (const auto& mtkDevice : mtkDevices) {
        if (deviceIdLower.find(mtkDevice) != std::string::npos) {
            return true;
        }
    }
    
    // We could also query the device for processor info
    Utils::AdbInterface adb;
    std::string output = adb.executeCommand("-s " + deviceId + " shell getprop ro.board.platform");
    
    // MTK platforms typically have "mt" prefix
    if (output.find("mt") != std::string::npos) {
        return true;
    }
    
    return false;
}

bool BBKProfile::isColorOSDevice(const std::string& deviceId) const {
    // Most OPPO and Realme devices use ColorOS
    Utils::AdbInterface adb;
    std::string output = adb.executeCommand("-s " + deviceId + " shell getprop ro.build.version.opporom");
    
    if (!output.empty() && output.find("not found") == std::string::npos) {
        return true;
    }
    
    // Check for other ColorOS indicators
    output = adb.executeCommand("-s " + deviceId + " shell getprop ro.build.display.id");
    if (output.find("ColorOS") != std::string::npos || output.find("OPPO") != std::string::npos || 
        output.find("Realme") != std::string::npos || output.find("RealmeUI") != std::string::npos) {
        return true;
    }
    
    return false;
}

BBKProfile::BBKBrand BBKProfile::detectBrand(const std::string& deviceId) const {
    Utils::AdbInterface adb;
    
    // Check model and manufacturer properties
    std::string manufacturer = adb.executeCommand("-s " + deviceId + " shell getprop ro.product.manufacturer");
    std::transform(manufacturer.begin(), manufacturer.end(), manufacturer.begin(), ::tolower);
    
    std::string model = adb.executeCommand("-s " + deviceId + " shell getprop ro.product.model");
    std::transform(model.begin(), model.end(), model.begin(), ::tolower);
    
    // Check brand property
    std::string brand = adb.executeCommand("-s " + deviceId + " shell getprop ro.product.brand");
    std::transform(brand.begin(), brand.end(), brand.begin(), ::tolower);
    
    // Check for OPPO
    if (brand.find("oppo") != std::string::npos || 
        manufacturer.find("oppo") != std::string::npos ||
        model.find("oppo") != std::string::npos ||
        model.find("cph") != std::string::npos ||  // OPPO model numbers often start with CPH
        model.find("find") != std::string::npos || 
        model.find("reno") != std::string::npos) {
        return BBKBrand::OPPO;
    }
    
    // Check for Realme
    if (brand.find("realme") != std::string::npos || 
        manufacturer.find("realme") != std::string::npos ||
        model.find("realme") != std::string::npos ||
        model.find("rmx") != std::string::npos) {  // Realme model numbers often start with RMX
        return BBKBrand::REALME;
    }
    
    // Check for Vivo
    if (brand.find("vivo") != std::string::npos || 
        manufacturer.find("vivo") != std::string::npos ||
        model.find("vivo") != std::string::npos ||
        model.find("v20") != std::string::npos || 
        model.find("v21") != std::string::npos ||
        model.find("v23") != std::string::npos ||
        model.find("v25") != std::string::npos) {
        return BBKBrand::VIVO;
    }
    
    // Check for OnePlus
    if (brand.find("oneplus") != std::string::npos || 
        manufacturer.find("oneplus") != std::string::npos ||
        model.find("oneplus") != std::string::npos ||
        model.find("nord") != std::string::npos) {
        return BBKBrand::ONEPLUS;
    }
    
    // Unknown BBK brand
    return BBKBrand::UNKNOWN;
}
/**
 * samsung.h
 * Samsung device-specific profile.
 */

#ifndef SAMSUNG_PROFILE_H
#define SAMSUNG_PROFILE_H

#include "device_profile.h"

class SamsungProfile : public DeviceProfile {
public:
    SamsungProfile();
    ~SamsungProfile() override = default;
    
    // Check if device requires OEM unlock to be enabled in developer options
    bool requiresOemUnlockEnabled() const override;
    
    // Enable OEM unlock in developer options
    bool enableOemUnlock(const std::string& deviceId) const override;
    
    // Get the fastboot command to unlock the bootloader
    std::string getBootloaderUnlockCommand() const override;
    
    // Get the fastboot command to flash recovery image
    std::string getRecoveryFlashCommand(const std::string& recoveryImagePath) const override;
    
    // Get the recovery partition name
    std::string getRecoveryPartitionName() const override;
    
    // Get any special ADB commands needed for this device
    std::map<std::string, std::string> getSpecialCommands() const override;
    
    // Get the manufacturer name
    std::string getManufacturer() const override;
    
    // Checks if the profile supports a specific device model
    bool supportsModel(const std::string& model) const override;
    
private:
    // List of supported Samsung models
    std::vector<std::string> supportedModels;
    
    // Check if device is Knox-enabled
    bool isKnoxEnabled(const std::string& deviceId) const;
    
    // Special handling for Odin mode devices
    bool isInOdinMode(const std::string& deviceId) const;
};

#endif // SAMSUNG_PROFILE_H

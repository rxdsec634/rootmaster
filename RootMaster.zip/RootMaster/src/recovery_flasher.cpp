/**
 * recovery_flasher.cpp
 * Implementation of recovery flashing functionality.
 */

#include "recovery_flasher.h"
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <filesystem>
#include <cstring>

RecoveryFlasher::RecoveryFlasher() {
    // Initialize resources
}

RecoveryFlasher::~RecoveryFlasher() {
    // Clean up resources
}

bool RecoveryFlasher::flashRecovery(const std::string& deviceId, 
                                  std::shared_ptr<DeviceProfile> deviceProfile, 
                                  const std::string& recoveryImagePath) {
    if (!deviceProfile) {
        std::cerr << "Error: No device profile provided for recovery flashing." << std::endl;
        return false;
    }
    
    // Verify recovery image
    if (!verifyRecoveryImage(recoveryImagePath)) {
        std::cerr << "Error: Invalid recovery image or file not found: " << recoveryImagePath << std::endl;
        return false;
    }
    
    // Make sure device is in bootloader mode
    std::cout << "Ensuring device is in bootloader mode..." << std::endl;
    if (!ensureDeviceInBootloader(deviceId)) {
        std::cerr << "Failed to put device in bootloader mode." << std::endl;
        return false;
    }
    
    // Get device-specific flash command from profile
    std::string flashCommand = deviceProfile->getRecoveryFlashCommand(recoveryImagePath);
    
    if (flashCommand.empty()) {
        std::cerr << "No recovery flash command available for this device model." << std::endl;
        return false;
    }
    
    // Execute the flash command
    std::cout << "Flashing recovery image..." << std::endl;
    std::string output = fastboot.executeCommand(flashCommand, deviceId);
    
    // Check for common error messages
    if (output.find("FAILED") != std::string::npos) {
        std::cerr << "Recovery flash failed: " << output << std::endl;
        return false;
    }
    
    std::cout << "Recovery image flashed successfully." << std::endl;
    
    // Reboot to recovery to verify
    std::cout << "Rebooting to recovery mode..." << std::endl;
    if (!rebootToRecovery(deviceId)) {
        std::cerr << "Warning: Failed to reboot to recovery mode." << std::endl;
        std::cerr << "Recovery may still have been flashed correctly." << std::endl;
        // Not treating this as a fatal error
        return true;
    }
    
    // Wait for device to appear in recovery mode
    if (!waitForRecoveryDevice(deviceId)) {
        std::cerr << "Warning: Device did not appear in recovery mode." << std::endl;
        std::cerr << "Recovery may still have been flashed correctly." << std::endl;
        // Not treating this as a fatal error
        return true;
    }
    
    std::cout << "Device successfully booted into recovery mode." << std::endl;
    return true;
}

bool RecoveryFlasher::rebootToRecovery(const std::string& deviceId) {
    // Check if we're in fastboot mode
    if (fastboot.isDeviceConnected(deviceId)) {
        std::string output = fastboot.executeCommand("reboot recovery", deviceId);
        return output.find("failed") == std::string::npos;
    }
    
    // If in ADB mode
    std::string command = "-s " + deviceId + " reboot recovery";
    std::string output = adb.executeCommand(command);
    return output.find("error") == std::string::npos;
}

bool RecoveryFlasher::verifyRecoveryImage(const std::string& recoveryImagePath) {
    // Check if file exists
    std::ifstream file(recoveryImagePath, std::ios::binary);
    if (!file.good()) {
        return false;
    }
    
    // Check file size (recovery images are typically at least a few MB)
    file.seekg(0, std::ios::end);
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    
    if (size < 1024 * 1024) { // Less than 1MB is suspicious
        std::cerr << "Warning: Recovery image file is unusually small (" << size / 1024 << " KB)" << std::endl;
        // We'll still attempt to use it, but warn the user
    }
    
    // Basic file header check for common image formats
    char header[8];
    file.read(header, sizeof(header));
    
    // Check for Android boot/recovery image magic (ANDROID!)
    if (memcmp(header, "ANDROID!", 8) == 0) {
        std::cout << "Verified Android boot/recovery image format." << std::endl;
        return true;
    }
    
    // Check for other common formats...
    // This is a simplified check and could be expanded
    
    std::cout << "Recovery image format not verified. Attempting to use anyway." << std::endl;
    return true;
}

bool RecoveryFlasher::ensureDeviceInBootloader(const std::string& deviceId) {
    // Check if already in fastboot mode
    if (fastboot.isDeviceConnected(deviceId)) {
        return true;
    }
    
    // Reboot to bootloader
    std::string command = "-s " + deviceId + " reboot bootloader";
    adb.executeCommand(command);
    
    // Wait for device to appear in fastboot
    return waitForFastbootDevice(deviceId);
}

bool RecoveryFlasher::waitForFastbootDevice(const std::string& deviceId, int timeoutSeconds) {
    std::cout << "Waiting for device to appear in fastboot mode..." << std::endl;
    
    for (int i = 0; i < timeoutSeconds; i++) {
        if (fastboot.isDeviceConnected(deviceId)) {
            std::cout << "Device detected in fastboot mode." << std::endl;
            return true;
        }
        
        // Check for any fastboot device if specific ID isn't found
        if (fastboot.isAnyDeviceConnected()) {
            std::cout << "A device is in fastboot mode, but its ID may have changed." << std::endl;
            return true;
        }
        
        std::cout << "." << std::flush;
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    
    std::cout << std::endl << "Timeout waiting for device in fastboot mode." << std::endl;
    return false;
}

bool RecoveryFlasher::waitForRecoveryDevice(const std::string& deviceId, int timeoutSeconds) {
    std::cout << "Waiting for device to appear in recovery mode..." << std::endl;
    
    for (int i = 0; i < timeoutSeconds; i++) {
        std::string output = adb.executeCommand("devices");
        
        // Look for the device ID and recovery state
        if (output.find(deviceId) != std::string::npos && 
            output.find("recovery") != std::string::npos) {
            std::cout << "Device detected in recovery mode." << std::endl;
            return true;
        }
        
        std::cout << "." << std::flush;
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    
    std::cout << std::endl << "Timeout waiting for device in recovery mode." << std::endl;
    return false;
}

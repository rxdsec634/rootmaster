#ifndef DOWNLOADER_H
#define DOWNLOADER_H

#include <string>
#include <map>
#include <vector>
#include <functional>

namespace Utils {

class Downloader {
public:
    // Function to download a TWRP recovery image for a specific device
    static bool downloadRecoveryImage(const std::string& deviceModel, const std::string& manufacturer, const std::string& outputPath);
    
    // Function to download Magisk installer
    static bool downloadMagisk(const std::string& outputPath, const std::string& version = "latest");
    
    // Get a list of available TWRP recovery images for a device
    static std::vector<std::string> getAvailableRecoveryVersions(const std::string& deviceModel, const std::string& manufacturer);
    
    // Get a list of available Magisk versions
    static std::vector<std::string> getAvailableMagiskVersions();
    
    // Check if a URL exists
    static bool urlExists(const std::string& url);
    
    // Download a file from URL to a local path
    static bool downloadFile(const std::string& url, const std::string& outputPath, 
                             std::function<void(int, int)> progressCallback = nullptr);
    
    // Get appropriate TWRP codename for a device
    static std::string getTwrpCodename(const std::string& deviceModel, const std::string& manufacturer);
    
private:
    // Map of common device model names to their TWRP codenames
    static std::map<std::string, std::string> deviceCodenames;
    
    // Map of manufacturer names to their TWRP codenames
    static std::map<std::string, std::string> manufacturerCodenames;
    
    // Base URLs for downloads
    static constexpr const char* TWRP_BASE_URL = "https://dl.twrp.me/";
    static constexpr const char* MAGISK_BASE_URL = "https://github.com/topjohnwu/Magisk/releases/download/";
    static constexpr const char* MAGISK_LATEST_URL = "https://github.com/topjohnwu/Magisk/releases/download/v28.1/Magisk-v28.1.apk";
    static constexpr const char* MAGISK_CANARY_URL = "https://raw.githubusercontent.com/topjohnwu/magisk-files/canary/app-debug.apk";
};

} // namespace Utils

#endif // DOWNLOADER_H
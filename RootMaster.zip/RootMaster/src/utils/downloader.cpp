#include "downloader.h"
#include "platform.h"
#include "filesystem.h"
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <regex>
#include <algorithm>
#include <filesystem>
#include <sstream>

namespace Utils {

std::map<std::string, std::string> Downloader::deviceCodenames = {
    // Google Pixel
    {"pixel", "pixel"},
    {"pixel xl", "marlin"},
    {"pixel 2", "walleye"},
    {"pixel 2 xl", "taimen"},
    {"pixel 3", "blueline"},
    {"pixel 3 xl", "crosshatch"},
    {"pixel 3a", "sargo"},
    {"pixel 3a xl", "bonito"},
    {"pixel 4", "flame"},
    {"pixel 4 xl", "coral"},
    {"pixel 4a", "sunfish"},
    {"pixel 5", "redfin"},
    {"pixel 5a", "barbet"},
    {"pixel 6", "oriole"},
    {"pixel 6 pro", "raven"},
    {"pixel 6a", "bluejay"},
    {"pixel 7", "panther"},
    {"pixel 7 pro", "cheetah"},
    
    // Samsung
    {"galaxy s7", "herolte"},
    {"galaxy s7 edge", "hero2lte"},
    {"galaxy s8", "dreamlte"},
    {"galaxy s8+", "dream2lte"},
    {"galaxy s9", "starlte"},
    {"galaxy s9+", "star2lte"},
    {"galaxy s10", "beyond1lte"},
    {"galaxy s10+", "beyond2lte"},
    {"galaxy s10e", "beyond0lte"},
    {"galaxy s20", "x1s"},
    {"galaxy s20+", "y2s"},
    {"galaxy s20 ultra", "z3s"},
    {"galaxy note 8", "greatlte"},
    {"galaxy note 9", "crownlte"},
    {"galaxy note 10", "d1"},
    {"galaxy note 10+", "d2s"},
    
    // Xiaomi
    {"redmi note 7", "lavender"},
    {"redmi note 8", "ginkgo"},
    {"redmi note 8 pro", "begonia"},
    {"redmi note 9", "merlin"},
    {"redmi note 9 pro", "joyeuse"},
    {"poco f1", "beryllium"},
    {"poco f2 pro", "lmi"},
    {"poco f3", "alioth"},
    {"poco x3", "surya"},
    {"poco x3 pro", "vayu"},
    {"mi 8", "dipper"},
    {"mi 9", "cepheus"},
    {"mi 10", "umi"},
    {"mi 11", "venus"},
    
    // OnePlus
    {"oneplus 5", "cheeseburger"},
    {"oneplus 5t", "dumpling"},
    {"oneplus 6", "enchilada"},
    {"oneplus 6t", "fajita"},
    {"oneplus 7", "guacamoleb"},
    {"oneplus 7 pro", "guacamole"},
    {"oneplus 7t", "hotdogb"},
    {"oneplus 7t pro", "hotdog"},
    {"oneplus 8", "instantnoodle"},
    {"oneplus 8 pro", "instantnoodlep"},
    {"oneplus 8t", "kebab"},
    {"oneplus 9", "lemonade"},
    {"oneplus 9 pro", "lemonadep"},
    
    // Realme
    {"realme 2 pro", "RMX1801"},
    {"realme 3 pro", "RMX1851"},
    {"realme 5 pro", "RMX1971"},
    {"realme x", "RMX1901"},
    {"realme x2 pro", "RMX1931"},
    {"realme 6 pro", "RMX2061"},
    {"realme 7 pro", "RMX2170"},
    {"realme gt", "RMX2202"},
    
    // Oppo
    {"find x2", "find-x2"},
    {"find x3 pro", "find-x3-pro"},
    {"reno 4", "reno4"},
    {"reno 5", "reno5"},
    {"reno 6", "reno6"},
    
    // Vivo
    {"vivo x60 pro", "vivo-x60-pro"},
    {"vivo nex 3", "vivo-nex-3"},
    
    // Tecno
    {"tecno camon 17", "tecno-camon-17"},
    {"tecno camon 18", "tecno-camon-18"},
    {"tecno spark 7", "tecno-spark-7"},
    
    // Infinix
    {"infinix note 10", "infinix-note-10"},
    {"infinix hot 10", "infinix-hot-10"}
};

std::map<std::string, std::string> Downloader::manufacturerCodenames = {
    {"google", "google"},
    {"pixel", "google"},
    {"samsung", "samsung"},
    {"xiaomi", "xiaomi"},
    {"redmi", "xiaomi"},
    {"poco", "xiaomi"},
    {"oneplus", "oneplus"},
    {"oppo", "oppo"},
    {"realme", "realme"},
    {"vivo", "vivo"},
    {"tecno", "tecno"},
    {"infinix", "infinix"},
    {"itel", "itel"}
};

bool Downloader::downloadFile(const std::string& url, const std::string& outputPath, 
                             std::function<void(int, int)> progressCallback) {
    
    // Create directories if they don't exist
    std::filesystem::path outputFilePath(outputPath);
    std::filesystem::create_directories(outputFilePath.parent_path());
    
    // Construct a curl command
    std::string command = "curl -L -o \"" + outputPath + "\" \"" + url + "\"";
    
    // Use --progress-bar option if we need a progress display
    if (progressCallback) {
        command += " --progress-bar";
    }
    
    std::cout << "Downloading: " << url << std::endl;
    std::cout << "To: " << outputPath << std::endl;
    
    // Execute the curl command
    int result = system(command.c_str());
    
    if (result != 0) {
        std::cerr << "Error: Failed to download file. Command returned: " << result << std::endl;
        // Only remove the file if it exists but is empty (failed download)
        if (std::filesystem::exists(outputPath) && std::filesystem::file_size(outputPath) == 0) {
            std::filesystem::remove(outputPath);
        }
        return false;
    }
    
    // Verify the file was downloaded properly
    if (!std::filesystem::exists(outputPath) || std::filesystem::file_size(outputPath) == 0) {
        std::cerr << "Error: Downloaded file is empty or does not exist." << std::endl;
        return false;
    }
    
    std::cout << "Download completed successfully!" << std::endl;
    return true;
}

bool Downloader::urlExists(const std::string& url) {
    // Use curl to just check headers (no download)
    std::string command = "curl -s -I -L \"" + url + "\" | grep -i \"HTTP/\" | tail -n 1";
    
    // Execute command and capture output
    std::string result = Platform::executeSystemCommand(command);
    
    // Parse the output for HTTP status code
    std::regex statusRegex("HTTP/[0-9.]+ ([0-9]+)");
    std::smatch match;
    
    if (std::regex_search(result, match, statusRegex) && match.size() > 1) {
        std::string statusCode = match[1].str();
        // 200 series are success codes
        return (statusCode.at(0) == '2');
    }
    
    return false;
}

std::string Downloader::getTwrpCodename(const std::string& deviceModel, const std::string& manufacturer) {
    std::string lowerModel = deviceModel;
    std::string lowerManufacturer = manufacturer;
    
    // Convert to lowercase for case-insensitive comparison
    std::transform(lowerModel.begin(), lowerModel.end(), lowerModel.begin(), ::tolower);
    std::transform(lowerManufacturer.begin(), lowerManufacturer.end(), lowerManufacturer.begin(), ::tolower);
    
    // Check if the exact model exists in our codename map
    if (deviceCodenames.find(lowerModel) != deviceCodenames.end()) {
        return deviceCodenames[lowerModel];
    }
    
    // If not found, try partial matching
    for (const auto& entry : deviceCodenames) {
        if (lowerModel.find(entry.first) != std::string::npos) {
            return entry.second;
        }
    }
    
    // If still not found, try to return a codename based on manufacturer
    if (manufacturerCodenames.find(lowerManufacturer) != manufacturerCodenames.end()) {
        std::string mfgCode = manufacturerCodenames[lowerManufacturer];
        // Try to construct a potential codename
        return mfgCode + "-" + lowerModel;
    }
    
    // If all else fails, return the lowercase model as a guess
    return lowerModel;
}

bool Downloader::downloadRecoveryImage(const std::string& deviceModel, 
                                      const std::string& manufacturer, 
                                      const std::string& outputPath) {
    
    std::string codename = getTwrpCodename(deviceModel, manufacturer);
    std::string twrpUrl = std::string(TWRP_BASE_URL) + codename + "/twrp-latest-" + codename + ".img";
    
    if (!urlExists(twrpUrl)) {
        std::cout << "Could not find TWRP image for " << deviceModel << " (" << codename << ")" << std::endl;
        std::cout << "Attempted URL: " << twrpUrl << std::endl;
        
        // Try alternative URL format
        twrpUrl = std::string(TWRP_BASE_URL) + codename + "/twrp-latest.img";
        
        if (!urlExists(twrpUrl)) {
            std::cout << "Alternative URL not found either: " << twrpUrl << std::endl;
            return false;
        }
    }
    
    std::cout << "Found TWRP recovery image for " << deviceModel << " (codename: " << codename << ")" << std::endl;
    
    // Use a progress display callback
    auto progressFunc = [](int downloaded, int total) {
        // This won't be used with system() approach, but kept for API compatibility
    };
    
    bool success = downloadFile(twrpUrl, outputPath, progressFunc);
    if (success) {
        std::cout << "TWRP recovery image downloaded successfully to " << outputPath << std::endl;
    }
    
    return success;
}

bool Downloader::downloadMagisk(const std::string& outputPath, const std::string& version) {
    std::string magiskUrl;
    std::string fileExtension;
    
    if (version == "latest") {
        magiskUrl = MAGISK_LATEST_URL;
        fileExtension = ".apk"; // Current latest version is an APK
    } else if (version == "canary") {
        magiskUrl = MAGISK_CANARY_URL;
        fileExtension = ".apk"; // Canary is always an APK
    } else {
        // Try APK format first (newer versions)
        magiskUrl = std::string(MAGISK_BASE_URL) + "v" + version + "/Magisk-v" + version + ".apk";
        fileExtension = ".apk";
        
        if (!urlExists(magiskUrl)) {
            // Try ZIP format (older versions)
            magiskUrl = std::string(MAGISK_BASE_URL) + "v" + version + "/Magisk-v" + version + ".zip";
            fileExtension = ".zip";
            
            if (!urlExists(magiskUrl)) {
                std::cout << "Could not find Magisk version " << version << std::endl;
                std::cout << "Attempted URLs: " << std::endl;
                std::cout << " - " << std::string(MAGISK_BASE_URL) + "v" + version + "/Magisk-v" + version + ".apk" << std::endl;
                std::cout << " - " << std::string(MAGISK_BASE_URL) + "v" + version + "/Magisk-v" + version + ".zip" << std::endl;
                
                // Fallback to latest version
                std::cout << "Falling back to latest version..." << std::endl;
                magiskUrl = MAGISK_LATEST_URL;
                fileExtension = ".apk"; // Latest version is an APK
            }
        }
    }
    
    // Ensure the output path has the correct extension
    std::string adjustedOutputPath = outputPath;
    
    // Check if the output path ends with .zip or .apk
    if (adjustedOutputPath.size() >= 4) {
        std::string currentExt = adjustedOutputPath.substr(adjustedOutputPath.size() - 4);
        if (currentExt == ".zip" && fileExtension == ".apk") {
            // Replace .zip with .apk
            adjustedOutputPath = adjustedOutputPath.substr(0, adjustedOutputPath.size() - 4) + ".apk";
            std::cout << "Note: Changed output extension to .apk to match the downloaded file format" << std::endl;
        } else if (currentExt == ".apk" && fileExtension == ".zip") {
            // Replace .apk with .zip
            adjustedOutputPath = adjustedOutputPath.substr(0, adjustedOutputPath.size() - 4) + ".zip";
            std::cout << "Note: Changed output extension to .zip to match the downloaded file format" << std::endl;
        }
    } else if (adjustedOutputPath.find('.') == std::string::npos) {
        // No extension at all, add the appropriate one
        adjustedOutputPath += fileExtension;
    }
    
    // Use a progress display callback
    auto progressFunc = [](int downloaded, int total) {
        // This won't be used with system() approach, but kept for API compatibility
    };
    
    bool success = downloadFile(magiskUrl, adjustedOutputPath, progressFunc);
    if (success) {
        std::cout << "Magisk installer downloaded successfully to " << adjustedOutputPath << std::endl;
    }
    
    return success;
}

std::vector<std::string> Downloader::getAvailableMagiskVersions() {
    std::vector<std::string> versions;
    
    // Most recent known versions
    versions.push_back("28.1");  // Current stable as of March 2025
    versions.push_back("27.0");
    versions.push_back("26.4");
    versions.push_back("26.1");
    versions.push_back("25.2");
    versions.push_back("25.0");
    versions.push_back("24.3");
    versions.push_back("24.1");
    versions.push_back("23.0");
    versions.push_back("22.0");
    versions.push_back("21.4");
    versions.push_back("20.4");
    
    // Add canary and latest options
    versions.push_back("latest");
    versions.push_back("canary");
    
    return versions;
}

std::vector<std::string> Downloader::getAvailableRecoveryVersions(const std::string& deviceModel, 
                                                                const std::string& manufacturer) {
    std::vector<std::string> versions;
    
    // At minimum, we can offer TWRP latest
    versions.push_back("latest");
    
    // Get the codename for this device
    std::string codename = getTwrpCodename(deviceModel, manufacturer);
    
    // Build the URL to check
    std::string indexUrl = std::string(TWRP_BASE_URL) + codename + "/";
    
    // Use curl to fetch the HTML content
    std::string command = "curl -s -L \"" + indexUrl + "\"";
    std::string response = Platform::executeSystemCommand(command);
    
    if (response.empty() || response.find("Error") == 0) {
        std::cerr << "Error: Failed to retrieve TWRP versions" << std::endl;
        return versions;
    }
    
    // Use regex to find all TWRP version strings in the response
    std::regex versionRegex("twrp-(\\d+\\.\\d+\\.\\d+)(?:-\\d+)?-" + codename + "\\.img");
    std::smatch match;
    std::string::const_iterator searchStart(response.cbegin());
    
    while (std::regex_search(searchStart, response.cend(), match, versionRegex)) {
        if (match.size() > 1) {
            versions.push_back(match[1].str());
        }
        searchStart = match.suffix().first;
    }
    
    return versions;
}

} // namespace Utils
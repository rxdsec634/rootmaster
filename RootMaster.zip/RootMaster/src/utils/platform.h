/**
 * platform.h
 * Provides platform-specific utilities and detection.
 */

#ifndef PLATFORM_H
#define PLATFORM_H

#include <string>

namespace Utils {

class Platform {
public:
    // Initialize platform-specific settings
    static void initialize();
    
    // Check if running on Windows
    static bool isWindows();
    
    // Check if running on macOS
    static bool isMac();
    
    // Check if running on Linux
    static bool isLinux();
    
    // Get platform name
    static std::string getPlatformName();
    
    // Get temporary directory path
    static std::string getTempDirectory();
    
    // Create a temporary file
    static std::string createTempFile(const std::string& prefix);
    
    // Execute a system command and get the output
    static std::string executeSystemCommand(const std::string& command);
};

} // namespace Utils

#endif // PLATFORM_H

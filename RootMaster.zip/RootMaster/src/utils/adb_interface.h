/**
 * adb_interface.h
 * Provides an interface to ADB (Android Debug Bridge).
 */

#ifndef ADB_INTERFACE_H
#define ADB_INTERFACE_H

#include <string>
#include <vector>
#include "platform.h"

namespace Utils {

class AdbInterface {
public:
    AdbInterface();
    ~AdbInterface();
    
    // Execute an ADB command and return the output
    std::string executeCommand(const std::string& command);
    
    // Check if ADB server is running
    bool isServerRunning();
    
    // Start ADB server
    bool startServer();
    
    // Kill ADB server
    bool killServer();
    
    // Check if a device is connected with the given ID
    bool isDeviceConnected(const std::string& deviceId);
    
    // Get list of connected devices
    std::vector<std::string> getConnectedDevices();
    
private:
    std::string adbPath; // Path to the ADB executable
    
    // Initialize ADB path
    void initAdbPath();
    
    // Format ADB command with proper path
    std::string formatCommand(const std::string& command);
};

} // namespace Utils

#endif // ADB_INTERFACE_H

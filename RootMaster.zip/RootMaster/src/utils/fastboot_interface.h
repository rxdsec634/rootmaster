/**
 * fastboot_interface.h
 * Provides an interface to Fastboot.
 */

#ifndef FASTBOOT_INTERFACE_H
#define FASTBOOT_INTERFACE_H

#include <string>
#include <vector>
#include "platform.h"

namespace Utils {

class FastbootInterface {
public:
    FastbootInterface();
    ~FastbootInterface();
    
    // Execute a Fastboot command and return the output
    std::string executeCommand(const std::string& command, const std::string& deviceId = "");
    
    // Check if a device is connected with the given ID
    bool isDeviceConnected(const std::string& deviceId);
    
    // Check if any device is connected in fastboot mode
    bool isAnyDeviceConnected();
    
    // Get list of connected devices in fastboot mode
    std::vector<std::string> getConnectedDevices();
    
private:
    std::string fastbootPath; // Path to the Fastboot executable
    
    // Initialize Fastboot path
    void initFastbootPath();
    
    // Format Fastboot command with proper path
    std::string formatCommand(const std::string& command, const std::string& deviceId);
};

} // namespace Utils

#endif // FASTBOOT_INTERFACE_H

/**
 * adb_interface.cpp
 * Implementation of ADB interface.
 */

#include "adb_interface.h"
#include <iostream>
#include <sstream>
#include <regex>
#include <cstdio>
#include <memory>
#include <stdexcept>
#include <array>
#include <fstream>
#include <filesystem>

namespace Utils {

AdbInterface::AdbInterface() {
    initAdbPath();
}

AdbInterface::~AdbInterface() {
    // Cleanup resources
}

void AdbInterface::initAdbPath() {
    // Try to find ADB in system path
    if (Platform::isWindows()) {
        adbPath = "adb.exe";
    } else {
        adbPath = "adb";
    }
    
    // Check if ADB exists in path
    std::string checkCommand;
    if (Platform::isWindows()) {
        checkCommand = "where " + adbPath;
    } else {
        checkCommand = "which " + adbPath;
    }
    
    std::array<char, 128> buffer;
    std::string result;
    
    try {
        std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(checkCommand.c_str(), "r"), pclose);
        if (!pipe) {
            throw std::runtime_error("Failed to check for ADB");
        }
        
        while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
            result += buffer.data();
        }
    } catch (const std::exception& e) {
        std::cerr << "Error checking for ADB: " << e.what() << std::endl;
    }
    
    if (!result.empty()) {
        // Remove whitespace
        result.erase(std::remove_if(result.begin(), result.end(), 
                                  [](unsigned char x) { return std::isspace(x); }), 
                    result.end());
        
        if (!result.empty()) {
            adbPath = result;
            return;
        }
    }
    
    // If we couldn't find ADB in the path, look in common locations
    std::vector<std::string> commonLocations;
    
    if (Platform::isWindows()) {
        commonLocations = {
            "C:\\Program Files\\Android\\platform-tools\\adb.exe",
            "C:\\Program Files (x86)\\Android\\platform-tools\\adb.exe",
            ".\\platform-tools\\adb.exe"
        };
    } else if (Platform::isMac()) {
        commonLocations = {
            "/Applications/Android Studio.app/Contents/platform-tools/adb",
            "/usr/local/bin/adb",
            "./platform-tools/adb"
        };
    } else {
        // Linux
        commonLocations = {
            "/usr/bin/adb",
            "/usr/local/bin/adb",
            "/opt/android-sdk/platform-tools/adb",
            "./platform-tools/adb"
        };
    }
    
    for (const auto& location : commonLocations) {
        std::ifstream file(location);
        if (file.good()) {
            adbPath = location;
            return;
        }
    }
    
    // If we still couldn't find ADB, we'll just use the command 'adb' and hope it's in the PATH
    if (Platform::isWindows()) {
        adbPath = "adb.exe";
    } else {
        adbPath = "adb";
    }
    
    std::cout << "Warning: ADB executable not found in common locations." << std::endl;
    std::cout << "Using '" << adbPath << "' and assuming it's in your PATH." << std::endl;
}

std::string AdbInterface::formatCommand(const std::string& command) {
    return "\"" + adbPath + "\" " + command;
}

std::string AdbInterface::executeCommand(const std::string& command) {
    std::string fullCommand = formatCommand(command);
    
    try {
        std::array<char, 128> buffer;
        std::string result;
        
        std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(fullCommand.c_str(), "r"), pclose);
        if (!pipe) {
            throw std::runtime_error("Failed to execute command: " + fullCommand);
        }
        
        while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
            result += buffer.data();
        }
        
        return result;
    } catch (const std::exception& e) {
        std::cerr << "Error executing ADB command: " << e.what() << std::endl;
        return "Error: " + std::string(e.what());
    }
}

bool AdbInterface::isServerRunning() {
    std::string result = executeCommand("devices");
    return result.find("List of devices attached") != std::string::npos;
}

bool AdbInterface::startServer() {
    std::string result = executeCommand("start-server");
    return result.find("error") == std::string::npos;
}

bool AdbInterface::killServer() {
    std::string result = executeCommand("kill-server");
    return result.find("error") == std::string::npos;
}

bool AdbInterface::isDeviceConnected(const std::string& deviceId) {
    std::string result = executeCommand("devices");
    return result.find(deviceId) != std::string::npos;
}

std::vector<std::string> AdbInterface::getConnectedDevices() {
    std::vector<std::string> devices;
    std::string result = executeCommand("devices");
    
    std::istringstream stream(result);
    std::string line;
    
    // Skip first line (header)
    std::getline(stream, line);
    
    // Parse each device line
    while (std::getline(stream, line)) {
        if (line.empty()) {
            continue;
        }
        
        std::istringstream lineStream(line);
        std::string deviceId;
        
        // Get device ID (first column)
        lineStream >> deviceId;
        
        if (!deviceId.empty()) {
            devices.push_back(deviceId);
        }
    }
    
    return devices;
}

} // namespace Utils

/**
 * filesystem.h
 * Provides file and directory manipulation utilities.
 */

#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <string>
#include <vector>
#include <cstdint>

namespace Utils {

class Filesystem {
public:
    // Create temporary directories for operations
    static void createTempDirectories();
    
    // Clean up temporary directories
    static void cleanupTempDirectories();
    
    // Check if a file exists
    static bool fileExists(const std::string& path);
    
    // Check if a directory exists
    static bool directoryExists(const std::string& path);
    
    // Create a directory
    static bool createDirectory(const std::string& path);
    
    // Delete a file
    static bool deleteFile(const std::string& path);
    
    // Delete a directory and its contents
    static bool deleteDirectory(const std::string& path);
    
    // Get the size of a file
    static std::uintmax_t fileSize(const std::string& path);
    
    // Copy a file
    static bool copyFile(const std::string& source, const std::string& destination);
    
    // Move a file
    static bool moveFile(const std::string& source, const std::string& destination);
    
    // Get the temporary working directory
    static std::string getTempWorkingDirectory();
    
private:
    static std::string tempWorkingDir; // Path to temporary working directory
};

} // namespace Utils

#endif // FILESYSTEM_H

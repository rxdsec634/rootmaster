/**
 * filesystem.cpp
 * Implementation of file and directory manipulation utilities.
 */

#include "filesystem.h"
#include "platform.h"
#include <iostream>
#include <fstream>
#include <filesystem>
#include <random>
#include <sstream>

namespace Utils {

std::string Filesystem::tempWorkingDir;

void Filesystem::createTempDirectories() {
    std::string tempDir = Platform::getTempDirectory();
    
    // Generate random directory name
    std::random_device rd;
    std::mt19937 mt(rd());
    std::uniform_int_distribution<int> dist(0, 999999);
    
    std::stringstream ss;
    ss << "rootmaster_" << dist(mt);
    std::string dirName = ss.str();
    
    // Create full path
    tempWorkingDir = tempDir + 
                    (Platform::isWindows() ? "\\" : "/") + 
                    dirName;
    
    // Create the directory
    try {
        std::filesystem::create_directory(tempWorkingDir);
        std::cout << "Created temporary working directory: " << tempWorkingDir << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error creating temporary directory: " << e.what() << std::endl;
        // Fallback
        tempWorkingDir = tempDir;
    }
}

void Filesystem::cleanupTempDirectories() {
    if (!tempWorkingDir.empty() && tempWorkingDir != Platform::getTempDirectory()) {
        try {
            std::uintmax_t removed = std::filesystem::remove_all(tempWorkingDir);
            std::cout << "Cleaned up temporary directory: " << tempWorkingDir 
                     << " (" << removed << " files/directories)" << std::endl;
        } catch (const std::exception& e) {
            std::cerr << "Error cleaning up temporary directory: " << e.what() << std::endl;
        }
    }
}

bool Filesystem::fileExists(const std::string& path) {
    try {
        return std::filesystem::exists(path) && std::filesystem::is_regular_file(path);
    } catch (const std::exception& e) {
        std::cerr << "Error checking if file exists: " << e.what() << std::endl;
        return false;
    }
}

bool Filesystem::directoryExists(const std::string& path) {
    try {
        return std::filesystem::exists(path) && std::filesystem::is_directory(path);
    } catch (const std::exception& e) {
        std::cerr << "Error checking if directory exists: " << e.what() << std::endl;
        return false;
    }
}

bool Filesystem::createDirectory(const std::string& path) {
    try {
        return std::filesystem::create_directories(path);
    } catch (const std::exception& e) {
        std::cerr << "Error creating directory: " << e.what() << std::endl;
        return false;
    }
}

bool Filesystem::deleteFile(const std::string& path) {
    try {
        return std::filesystem::remove(path);
    } catch (const std::exception& e) {
        std::cerr << "Error deleting file: " << e.what() << std::endl;
        return false;
    }
}

bool Filesystem::deleteDirectory(const std::string& path) {
    try {
        return std::filesystem::remove_all(path) > 0;
    } catch (const std::exception& e) {
        std::cerr << "Error deleting directory: " << e.what() << std::endl;
        return false;
    }
}

std::uintmax_t Filesystem::fileSize(const std::string& path) {
    try {
        return std::filesystem::file_size(path);
    } catch (const std::exception& e) {
        std::cerr << "Error getting file size: " << e.what() << std::endl;
        return 0;
    }
}

bool Filesystem::copyFile(const std::string& source, const std::string& destination) {
    try {
        std::filesystem::copy_file(source, destination, 
                                 std::filesystem::copy_options::overwrite_existing);
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error copying file: " << e.what() << std::endl;
        return false;
    }
}

bool Filesystem::moveFile(const std::string& source, const std::string& destination) {
    try {
        std::filesystem::rename(source, destination);
        return true;
    } catch (const std::exception& e) {
        // If cross-device move fails, try copy and delete
        try {
            std::filesystem::copy_file(source, destination, 
                                     std::filesystem::copy_options::overwrite_existing);
            std::filesystem::remove(source);
            return true;
        } catch (const std::exception& e2) {
            std::cerr << "Error moving file: " << e2.what() << std::endl;
            return false;
        }
    }
}

std::string Filesystem::getTempWorkingDirectory() {
    return tempWorkingDir;
}

} // namespace Utils

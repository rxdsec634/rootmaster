/**
 * platform.cpp
 * Implementation of platform-specific utilities.
 */

#include "platform.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <memory>
#include <stdexcept>
#include <array>
#include <filesystem>
#include <random>
#include <sstream>

#ifdef _WIN32
    #include <windows.h>
    #define PLATFORM_WINDOWS
#elif __APPLE__
    #include <mach-o/dyld.h>
    #define PLATFORM_MAC
#else
    #include <unistd.h>
    #define PLATFORM_LINUX
#endif

namespace Utils {

void Platform::initialize() {
    // Set up any platform-specific configurations
    
    // On Windows, set UTF-8 console output
#ifdef PLATFORM_WINDOWS
    SetConsoleOutputCP(CP_UTF8);
#endif
}

bool Platform::isWindows() {
#ifdef PLATFORM_WINDOWS
    return true;
#else
    return false;
#endif
}

bool Platform::isMac() {
#ifdef PLATFORM_MAC
    return true;
#else
    return false;
#endif
}

bool Platform::isLinux() {
#ifdef PLATFORM_LINUX
    return true;
#else
    return false;
#endif
}

std::string Platform::getPlatformName() {
    if (isWindows()) {
        return "Windows";
    } else if (isMac()) {
        return "macOS";
    } else if (isLinux()) {
        return "Linux";
    } else {
        return "Unknown";
    }
}

std::string Platform::getTempDirectory() {
    try {
        return std::filesystem::temp_directory_path().string();
    } catch (const std::exception& e) {
        // Fallback to standard temp directories
        if (isWindows()) {
            return "C:\\Temp";
        } else {
            return "/tmp";
        }
    }
}

std::string Platform::createTempFile(const std::string& prefix) {
    std::string tempDir = getTempDirectory();
    
    // Generate random suffix
    std::random_device rd;
    std::mt19937 mt(rd());
    std::uniform_int_distribution<int> dist(0, 999999);
    
    std::stringstream ss;
    ss << prefix << "_" << dist(mt);
    std::string tempFileName = ss.str();
    
    std::string tempFilePath = tempDir + 
                              (isWindows() ? "\\" : "/") + 
                              tempFileName;
    
    // Create empty file
    std::ofstream tempFile(tempFilePath);
    tempFile.close();
    
    return tempFilePath;
}

std::string Platform::executeSystemCommand(const std::string& command) {
    std::array<char, 128> buffer;
    std::string result;
    
    try {
        std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(command.c_str(), "r"), pclose);
        if (!pipe) {
            throw std::runtime_error("Failed to execute command: " + command);
        }
        
        while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
            result += buffer.data();
        }
    } catch (const std::exception& e) {
        std::cerr << "Error executing system command: " << e.what() << std::endl;
        return "Error: " + std::string(e.what());
    }
    
    return result;
}

} // namespace Utils

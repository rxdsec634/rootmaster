/**
 * device_detector.cpp
 * Implementation of device detection and information gathering functions.
 */

#include "device_detector.h"
#include "utils/fastboot_interface.h"
#include "utils/platform.h"
#include "device_profiles/device_profile.h"
#include <sstream>
#include <iostream>
#include <algorithm>
#include <regex>

DeviceDetector::DeviceDetector() {
    // Initialize ADB interface
}

DeviceDetector::~DeviceDetector() {
    // Clean up resources
}

std::vector<DeviceInfo> DeviceDetector::detectDevices() {
    std::vector<DeviceInfo> devices;
    
    // Check for devices in normal mode using ADB
    std::string adbOutput = adb.executeCommand("devices -l");
    auto adbDevices = parseAdbDevices(adbOutput);
    devices.insert(devices.end(), adbDevices.begin(), adbDevices.end());
    
    // Check for devices in fastboot mode
    Utils::FastbootInterface fastboot;
    std::string fastbootOutput = fastboot.executeCommand("devices");
    auto fastbootDevices = parseFastbootDevices(fastbootOutput);
    devices.insert(devices.end(), fastbootDevices.begin(), fastbootDevices.end());
    
    return devices;
}

bool DeviceDetector::isDeviceConnected(const std::string& deviceId) {
    auto devices = detectDevices();
    for (const auto& device : devices) {
        if (device.id == deviceId) {
            return true;
        }
    }
    return false;
}

DetailedDeviceInfo DeviceDetector::getDetailedInfo(const std::string& deviceId) {
    DetailedDeviceInfo info;
    info.id = deviceId;
    info.isSupported = true;
    
    // Check if device is in fastboot mode
    if (isInFastbootMode(deviceId)) {
        // Limited information available in fastboot mode
        Utils::FastbootInterface fastboot;
        std::string output = fastboot.executeCommand("getvar product", deviceId);
        
        // Extract model information from fastboot output
        std::regex modelRegex("product:\\s*(.+)");
        std::smatch match;
        if (std::regex_search(output, match, modelRegex) && match.size() > 1) {
            info.model = match[1].str();
        } else {
            info.model = "Unknown (Fastboot Mode)";
        }
        
        // Get bootloader status
        output = fastboot.executeCommand("getvar unlocked", deviceId);
        info.bootloaderUnlocked = (output.find("unlocked: yes") != std::string::npos);
        
        // Limited information in fastboot mode
        info.androidVersion = "Unknown (Fastboot Mode)";
        info.cpuArch = "Unknown (Fastboot Mode)";
        info.manufacturer = "Unknown (Fastboot Mode)";
        info.buildFingerprint = "Unknown (Fastboot Mode)";
        
        return info;
    }
    
    // Get device properties using ADB if in normal or recovery mode
    std::map<std::string, std::string> properties = getDeviceProperties(deviceId);
    
    // Extract relevant information
    info.model = properties["ro.product.model"];
    info.manufacturer = properties["ro.product.manufacturer"];
    info.androidVersion = properties["ro.build.version.release"];
    info.cpuArch = properties["ro.product.cpu.abi"];
    info.buildFingerprint = properties["ro.build.fingerprint"];
    
    // Check bootloader status
    info.bootloaderUnlocked = (properties["ro.boot.flash.locked"] == "0" || 
                               properties["ro.boot.unlocked"] == "true" ||
                               properties["ro.bootloader.unlocked"] == "1");
    
    // Check device compatibility
    if (!isDeviceCompatible(info)) {
        info.isSupported = false;
        info.unsupportedReason = "Device is not on the supported list or is known to have issues with rooting.";
    }
    
    return info;
}

bool DeviceDetector::isDeviceCompatible(const DetailedDeviceInfo& deviceInfo) {
    // Check if device is blacklisted
    if (isDeviceBlacklisted(deviceInfo)) {
        return false;
    }
    
    // Check if device manufacturer is supported
    std::string manufacturer = deviceInfo.manufacturer;
    std::transform(manufacturer.begin(), manufacturer.end(), manufacturer.begin(), ::tolower);
    
    // Check model as well for additional detection capability
    std::string model = deviceInfo.model;
    std::transform(model.begin(), model.end(), model.begin(), ::tolower);
    
    // List of supported Google/Pixel devices
    if (manufacturer.find("google") != std::string::npos || 
        manufacturer.find("pixel") != std::string::npos) {
        return true;
    }
    
    // List of supported Samsung devices
    if (manufacturer.find("samsung") != std::string::npos) {
        return true;
    }
    
    // List of supported Xiaomi/Redmi/Poco devices
    if (manufacturer.find("xiaomi") != std::string::npos || 
        manufacturer.find("redmi") != std::string::npos || 
        manufacturer.find("poco") != std::string::npos ||
        model.find("mi") != std::string::npos ||
        model.find("redmi") != std::string::npos ||
        model.find("poco") != std::string::npos) {
        return true;
    }
    
    // List of supported BBK Electronics brands (Oppo, Vivo, Realme, OnePlus)
    if (manufacturer.find("oppo") != std::string::npos || 
        manufacturer.find("vivo") != std::string::npos || 
        manufacturer.find("realme") != std::string::npos || 
        manufacturer.find("oneplus") != std::string::npos ||
        manufacturer.find("bbk") != std::string::npos ||
        model.find("oppo") != std::string::npos ||
        model.find("vivo") != std::string::npos ||
        model.find("realme") != std::string::npos ||
        model.find("oneplus") != std::string::npos ||
        model.find("nord") != std::string::npos ||
        model.find("reno") != std::string::npos ||
        model.find("find") != std::string::npos) {
        return true;
    }
    
    // List of supported Transsion Holdings brands (Tecno, Infinix, Itel)
    if (manufacturer.find("tecno") != std::string::npos || 
        manufacturer.find("infinix") != std::string::npos || 
        manufacturer.find("itel") != std::string::npos ||
        manufacturer.find("transsion") != std::string::npos ||
        model.find("tecno") != std::string::npos ||
        model.find("infinix") != std::string::npos ||
        model.find("itel") != std::string::npos ||
        model.find("camon") != std::string::npos ||
        model.find("spark") != std::string::npos ||
        model.find("hot") != std::string::npos) {
        return true;
    }
    
    // Check via device profile to cover edge cases
    // Try to create a profile for this device
    std::shared_ptr<DeviceProfile> profile = DeviceProfile::createProfileForDevice(deviceInfo);
    if (profile) {
        return true;
    }
    
    // If we can't determine compatibility, err on the side of caution
    return false;
}

bool DeviceDetector::isDeviceBlacklisted(const DetailedDeviceInfo& deviceInfo) {
    // List of devices known to have serious issues with rooting
    // or devices with special requirements that we don't support yet
    
    // Samsung devices with Knox security might have issues
    if (deviceInfo.manufacturer.find("samsung") != std::string::npos) {
        // Check for Knox devices that can't be safely rooted
        // For now, we're being cautious and allowing all Samsung devices
        // but we could add specific problematic models here
    }
    
    // Devices with verified boot security that can't be easily bypassed
    // These are just examples and would need to be updated based on actual testing
    std::vector<std::string> blacklistedDevices = {
        "samsungexynos9810", // Example - would need real testing
        "pixel6xl",          // Example - would need real testing
    };
    
    std::string modelLower = deviceInfo.model;
    std::transform(modelLower.begin(), modelLower.end(), modelLower.begin(), ::tolower);
    modelLower.erase(std::remove_if(modelLower.begin(), modelLower.end(), ::isspace), modelLower.end());
    
    for (const auto& device : blacklistedDevices) {
        if (modelLower.find(device) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

std::vector<DeviceInfo> DeviceDetector::parseAdbDevices(const std::string& output) {
    std::vector<DeviceInfo> devices;
    std::istringstream stream(output);
    std::string line;
    
    // Skip the first line (header)
    std::getline(stream, line);
    
    // Parse each device line
    while (std::getline(stream, line)) {
        if (line.empty()) {
            continue;
        }
        
        std::istringstream lineStream(line);
        DeviceInfo device;
        
        // Get device ID
        lineStream >> device.id;
        
        // Get device state
        lineStream >> device.state;
        
        // Extract model information
        std::regex modelRegex("model:([\\w-]+)");
        std::smatch match;
        if (std::regex_search(line, match, modelRegex) && match.size() > 1) {
            device.model = match[1].str();
        } else {
            device.model = "Unknown";
            
            // Try to get model from props if we can
            if (device.state == "device") {
                std::string modelOutput = adb.executeCommand("-s " + device.id + " shell getprop ro.product.model");
                if (!modelOutput.empty()) {
                    device.model = modelOutput;
                }
            }
        }
        
        // Only add devices that are in a usable state
        if (!device.id.empty() && (device.state == "device" || device.state == "recovery" || device.state == "sideload")) {
            devices.push_back(device);
        }
    }
    
    return devices;
}

std::vector<DeviceInfo> DeviceDetector::parseFastbootDevices(const std::string& output) {
    std::vector<DeviceInfo> devices;
    std::istringstream stream(output);
    std::string line;
    
    // Parse each device line
    while (std::getline(stream, line)) {
        if (line.empty()) {
            continue;
        }
        
        std::istringstream lineStream(line);
        DeviceInfo device;
        
        // Get device ID
        lineStream >> device.id;
        
        // fastboot devices only shows devices in fastboot mode
        device.state = "fastboot";
        
        // Limited model information in fastboot mode
        device.model = "Unknown (Fastboot)";
        
        if (!device.id.empty()) {
            devices.push_back(device);
        }
    }
    
    return devices;
}

std::map<std::string, std::string> DeviceDetector::getDeviceProperties(const std::string& deviceId) {
    std::map<std::string, std::string> properties;
    
    // Get properties using ADB
    std::string command = "-s " + deviceId + " shell getprop";
    std::string output = adb.executeCommand(command);
    
    // Parse the output to extract properties
    std::regex propRegex("\\[([^\\]]+)\\]:\\s*\\[([^\\]]+)\\]");
    auto propBegin = std::sregex_iterator(output.begin(), output.end(), propRegex);
    auto propEnd = std::sregex_iterator();
    
    for (std::sregex_iterator i = propBegin; i != propEnd; ++i) {
        std::smatch match = *i;
        std::string key = match[1].str();
        std::string value = match[2].str();
        properties[key] = value;
    }
    
    return properties;
}

bool DeviceDetector::isInFastbootMode(const std::string& deviceId) {
    Utils::FastbootInterface fastboot;
    std::string output = fastboot.executeCommand("devices");
    return output.find(deviceId) != std::string::npos;
}

bool DeviceDetector::isInRecoveryMode(const std::string& deviceId) {
    std::string output = adb.executeCommand("devices");
    return output.find(deviceId) != std::string::npos && output.find("recovery") != std::string::npos;
}

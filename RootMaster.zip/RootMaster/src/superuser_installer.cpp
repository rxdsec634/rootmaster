/**
 * superuser_installer.cpp
 * Implementation of superuser binary installation functionality.
 */

#include "superuser_installer.h"
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <filesystem>
#include <regex>

SuperuserInstaller::SuperuserInstaller() {
    // Initialize resources
}

SuperuserInstaller::~SuperuserInstaller() {
    // Clean up resources
}

bool SuperuserInstaller::installSuperuser(const std::string& deviceId, 
                                         std::shared_ptr<DeviceProfile> deviceProfile,
                                         const std::string& magiskPath) {
    if (!deviceProfile) {
        std::cerr << "Error: No device profile provided for superuser installation." << std::endl;
        return false;
    }
    
    // Verify Magisk ZIP
    if (!verifyMagiskZip(magiskPath)) {
        std::cerr << "Error: Invalid Magisk ZIP or file not found: " << magiskPath << std::endl;
        return false;
    }
    
    // Make sure device is in recovery mode
    std::cout << "Ensuring device is in recovery mode..." << std::endl;
    if (!ensureDeviceInRecovery(deviceId)) {
        std::cerr << "Failed to put device in recovery mode." << std::endl;
        return false;
    }
    
    // Push Magisk ZIP to device
    std::cout << "Pushing Magisk installer to device..." << std::endl;
    if (!pushMagiskToDevice(deviceId, magiskPath)) {
        std::cerr << "Failed to push Magisk to device." << std::endl;
        return false;
    }
    
    // Install Magisk in recovery
    std::cout << "Installing Magisk..." << std::endl;
    if (!installMagiskInRecovery(deviceId, magiskPath)) {
        std::cerr << "Failed to install Magisk." << std::endl;
        return false;
    }
    
    // Reboot device
    std::cout << "Rebooting device..." << std::endl;
    std::string command = "-s " + deviceId + " reboot";
    adb.executeCommand(command);
    
    // Wait for device to boot
    std::cout << "Waiting for device to boot..." << std::endl;
    if (!waitForNormalBoot(deviceId)) {
        std::cerr << "Warning: Device did not boot within expected timeframe." << std::endl;
        std::cerr << "Magisk may still have been installed correctly." << std::endl;
        // Not treating this as a fatal error
        return true;
    }
    
    // Verify Magisk installation
    if (!verifyMagiskInstallation(deviceId)) {
        std::cerr << "Warning: Could not verify Magisk installation." << std::endl;
        std::cerr << "It might still be installed but not detectable via ADB." << std::endl;
        return false;
    }
    
    std::cout << "Magisk installed successfully!" << std::endl;
    return true;
}

bool SuperuserInstaller::verifyMagiskInstallation(const std::string& deviceId) {
    // Check if Magisk app is installed
    std::string command = "-s " + deviceId + " shell pm list packages | grep magisk";
    std::string output = adb.executeCommand(command);
    
    if (output.find("com.topjohnwu.magisk") != std::string::npos) {
        std::cout << "Magisk app detected." << std::endl;
        return true;
    }
    
    // Check if su binary exists and is executable
    command = "-s " + deviceId + " shell which su";
    output = adb.executeCommand(command);
    
    if (!output.empty() && output.find("not found") == std::string::npos) {
        std::cout << "Superuser binary detected at: " << output << std::endl;
        return true;
    }
    
    // Try to check for Magisk modules directory
    command = "-s " + deviceId + " shell ls -la /data/adb/modules";
    output = adb.executeCommand(command);
    
    if (output.find("No such file") == std::string::npos) {
        std::cout << "Magisk modules directory detected." << std::endl;
        return true;
    }
    
    return false;
}

bool SuperuserInstaller::verifyMagiskZip(const std::string& magiskPath) {
    // Check if file exists
    std::ifstream file(magiskPath, std::ios::binary);
    if (!file.good()) {
        return false;
    }
    
    // Check file extension
    std::filesystem::path path(magiskPath);
    std::string extension = path.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), ::tolower);
    
    if (extension != ".zip") {
        std::cerr << "Warning: Magisk installer should be a ZIP file." << std::endl;
        // We'll still attempt to use it, but warn the user
    }
    
    // Check file size (Magisk ZIPs are typically several MB)
    file.seekg(0, std::ios::end);
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    
    if (size < 1024 * 1024) { // Less than 1MB is suspicious
        std::cerr << "Warning: Magisk ZIP file is unusually small (" << size / 1024 << " KB)" << std::endl;
        // We'll still attempt to use it, but warn the user
    }
    
    // Look for common Magisk ZIP file patterns
    // This is not a comprehensive check but helps catch obvious issues
    std::string filename = path.filename().string();
    if (filename.find("magisk") == std::string::npos && 
        filename.find("Magisk") == std::string::npos) {
        std::cerr << "Warning: File name does not contain 'Magisk'" << std::endl;
        // We'll still attempt to use it, but warn the user
    }
    
    return true;
}

bool SuperuserInstaller::ensureDeviceInRecovery(const std::string& deviceId) {
    // Check if already in recovery mode
    std::string output = adb.executeCommand("devices");
    if (output.find(deviceId) != std::string::npos && 
        output.find("recovery") != std::string::npos) {
        return true;
    }
    
    // Reboot to recovery
    std::string command = "-s " + deviceId + " reboot recovery";
    adb.executeCommand(command);
    
    // Wait for device to appear in recovery mode
    std::cout << "Waiting for device to boot into recovery..." << std::endl;
    for (int i = 0; i < 60; i++) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        output = adb.executeCommand("devices");
        
        if (output.find(deviceId) != std::string::npos && 
            output.find("recovery") != std::string::npos) {
            std::cout << "Device detected in recovery mode." << std::endl;
            
            // Give recovery a moment to fully initialize
            std::this_thread::sleep_for(std::chrono::seconds(5));
            return true;
        }
        
        std::cout << "." << std::flush;
    }
    
    std::cout << std::endl << "Timeout waiting for device in recovery mode." << std::endl;
    return false;
}

bool SuperuserInstaller::pushMagiskToDevice(const std::string& deviceId, const std::string& magiskPath) {
    // Extract filename from path
    std::filesystem::path path(magiskPath);
    std::string filename = path.filename().string();
    
    // Create target path on device
    std::string devicePath = "/sdcard/" + filename;
    
    // Push file to device
    std::string command = "-s " + deviceId + " push \"" + magiskPath + "\" \"" + devicePath + "\"";
    std::string output = adb.executeCommand(command);
    
    // Check for errors in output
    if (output.find("error") != std::string::npos || output.find("failed") != std::string::npos) {
        std::cerr << "Error pushing file: " << output << std::endl;
        return false;
    }
    
    return true;
}

bool SuperuserInstaller::installMagiskInRecovery(const std::string& deviceId, const std::string& magiskPath) {
    // Extract filename from path
    std::filesystem::path path(magiskPath);
    std::string filename = path.filename().string();
    std::string devicePath = "/sdcard/" + filename;
    
    // The command depends on the recovery type (TWRP or stock)
    
    // First, check if we're in TWRP
    std::string output = adb.executeCommand("-s " + deviceId + " shell getprop ro.twrp.version");
    bool isTwrp = !output.empty() && output.find("not found") == std::string::npos;
    
    if (isTwrp) {
        std::cout << "TWRP recovery detected. Installing Magisk via TWRP..." << std::endl;
        
        // TWRP installation method
        std::string command = "-s " + deviceId + " shell twrp install \"" + devicePath + "\"";
        output = adb.executeCommand(command);
        
        if (output.find("Error") != std::string::npos || output.find("failed") != std::string::npos) {
            // Try alternative method for older TWRP versions
            command = "-s " + deviceId + " shell install /sdcard/" + filename;
            output = adb.executeCommand(command);
        }
    } else {
        std::cout << "Stock recovery detected. Attempting to install Magisk..." << std::endl;
        
        // For stock recovery, try sideloading method
        // First try to enter sideload mode
        std::string command = "-s " + deviceId + " shell --command \"reboot sideload\"";
        adb.executeCommand(command);
        
        // Wait for sideload mode
        std::this_thread::sleep_for(std::chrono::seconds(5));
        
        // Sideload the ZIP
        command = "sideload \"" + magiskPath + "\"";
        output = adb.executeCommand(command);
    }
    
    // Check for errors
    if (output.find("Error") != std::string::npos || 
        output.find("failed") != std::string::npos || 
        output.find("Failed") != std::string::npos) {
        std::cerr << "Error installing Magisk: " << output << std::endl;
        return false;
    }
    
    return true;
}

bool SuperuserInstaller::waitForNormalBoot(const std::string& deviceId, int timeoutSeconds) {
    std::cout << "Waiting for device to boot normally..." << std::endl;
    
    for (int i = 0; i < timeoutSeconds; i++) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        
        // Check if device is online
        std::string output = adb.executeCommand("devices");
        if (output.find(deviceId) != std::string::npos && 
            output.find("device") != std::string::npos && 
            output.find("recovery") == std::string::npos) {
            
            // Check if boot completed
            std::string bootCompleted = adb.executeCommand("-s " + deviceId + 
                                                         " shell getprop sys.boot_completed");
            bootCompleted.erase(std::remove_if(bootCompleted.begin(), bootCompleted.end(), 
                                             ::isspace), bootCompleted.end());
            
            if (bootCompleted == "1") {
                std::cout << "Device booted successfully." << std::endl;
                return true;
            }
        }
        
        std::cout << "." << std::flush;
    }
    
    std::cout << std::endl << "Timeout waiting for device to boot normally." << std::endl;
    return false;
}

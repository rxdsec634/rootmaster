/**
 * bootloader_manager.h
 * Handles bootloader unlocking operations.
 */

#ifndef BOOTLOADER_MANAGER_H
#define BOOTLOADER_MANAGER_H

#include <string>
#include <memory>
#include "device_profiles/device_profile.h"
#include "utils/adb_interface.h"
#include "utils/fastboot_interface.h"

class BootloaderManager {
public:
    BootloaderManager();
    ~BootloaderManager();
    
    // Unlock bootloader for a specific device
    bool unlockBootloader(const std::string& deviceId, std::shared_ptr<DeviceProfile> deviceProfile);
    
    // Reboot device to bootloader mode
    bool rebootToBootloader(const std::string& deviceId);
    
    // Reboot device to normal mode
    bool rebootDevice(const std::string& deviceId);
    
    // Check if bootloader is unlocked
    bool isBootloaderUnlocked(const std::string& deviceId);
    
private:
    Utils::AdbInterface adb;
    Utils::FastbootInterface fastboot;
    
    // Wait for device to appear in fastboot mode
    bool waitForFastbootDevice(const std::string& deviceId, int timeoutSeconds = 60);
    
    // Execute manufacturer-specific bootloader unlock sequence
    bool executeUnlockSequence(const std::string& deviceId, std::shared_ptr<DeviceProfile> deviceProfile);
};

#endif // BOOTLOADER_MANAGER_H
